(* -*- holl -*- *)

prioritize_real ();;

let REAL_MUL_EQ_0 = prove
  (`!m n : real. m * n = &0 <=> m = &0 \/ n = &0`,
   CONV_TAC REAL_RING);;

let REAL_INTEGRAL_LEMMA = prove
 (`(!x. &0 * x = &0) /\
   (!x y z. (x + y = x + z) <=> (y = z)) /\
   (!w x y z. (w * y + x * z = w * z + x * y) <=>
              (w = x) \/ (y = z))`,
   CONV_TAC REAL_RING);;

let REAL_INTEGRAL_LEMMA1 = prove
  (`w * y + x * z = w * z + x * y <=> w = x \/ y = z`,
   CONV_TAC REAL_RING);;

prioritize_int ();;


let INT_MUL_EQ_0 = INT_OF_REAL_THM REAL_MUL_EQ_0;;

let INT_INTEGRAL_LEMMA1 = INT_OF_REAL_THM REAL_INTEGRAL_LEMMA1;;

let INT_INTEGRAL_LEMMA = prove
  (`(w = x + d) /\ (y = z + e)
     ==> ((w * y + x * z = w * z + x * y) <=>
         (w = x) \/ (y = z))`,
   DISCH_THEN(fun th -> REWRITE_TAC[th]) THEN
   REWRITE_TAC[INT_ADD_LDISTRIB; INT_ADD_RDISTRIB;
               GSYM INT_ADD_ASSOC] THEN
   ONCE_REWRITE_TAC[AC INT_ADD_AC
     `a + b + c + d + e = a + c + e + b + d`] THEN
   REWRITE_TAC[INT_EQ_ADD_LCANCEL; INT_EQ_ADD_LCANCEL_0;
               INT_MUL_EQ_0]);;

let INT_INTEGRAL_LEMMA = prove
  (`(!x. &0 * x = &0) /\
    (!x y z. (x + y = x + z) <=> (y = z)) /\
    (!w x y z. (w * y + x * z = w * z + x * y) <=>
               (w = x) \/ (y = z))`,
   REWRITE_TAC [INT_EQ_ADD_LCANCEL; INT_MUL_LZERO;
                INT_INTEGRAL_LEMMA1]);;

let INT_RING =
  let rawring =
    RING(dest_numeral,mk_numeral,INT_EQ_CONV,
         genvar bool_ty,`(+):num->num->num`,genvar bool_ty,
         genvar bool_ty,`( * ):num->num->num`,genvar bool_ty,
         `(EXP):num->num->num`,
         INT_INTEGRAL,INT_NORMALIZE_CONV) in
  let initconv = INT_SIMPLIFY_CONV THENC GEN_REWRITE_CONV DEPTH_CONV [ADD1]
  and t_tm = `T` in
  fun tm -> let th = initconv tm in
            if rand(concl th) = t_tm then th
            else EQ_MP (SYM th) (rawring(rand(concl th)));;


let GW_BASIC = new_definition
  `!GW. GW_BASIC GW <=>
         (!a x y z. GW a x y z = GW a y x z) /\
   	 (!a x y z. GW a x y z = GW a x z y) /\
   	 (!a x x' y z. GW a (x + x') y z =
 	               GW a x z y + GW a x' z y)`;;

