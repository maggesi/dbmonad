(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "Operad/operad.ml";;
needs "Operad/lc.ml";;

g `OPERAD SUBST REF`;;
e (REWRITE_TAC [OPERAD_DEF]);;
e (REPEAT CONJ_TAC);;
e (REWRITE_TAC [SUBST]);;
e (REWRITE_TAC [SUBST_REF_UNIT_L]);;
e (REWRITE_TAC [SUBST_SUBST; o_DEF]);;
let SLC_OPERAD = top_thm ();;

g `OPERAD LC_SUBST LC_REF`;;
e (REWRITE_TAC [OPERAD_DEF]);;
e (REPEAT CONJ_TAC);;
e (REWRITE_TAC [LC_SUBST_REF_UNIT_R]);;
e (REWRITE_TAC [LC_SUBST_REF_UNIT_L]);;
e (REWRITE_TAC [LC_SUBST_ASSOC; o_DEF]);;
let LC_OPERAD = top_thm ();;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `ABS (SUBST (\n. if n < SUC 0 then REF n
                   else SUBST (\n. REF (SUC n)) (f (PRE n))) x) =
   SUBST f (ABS x)`;;
e (REWRITE_TAC [SUBST; ABS_INJ]);;
e (AP_THM_TAC THEN AP_TERM_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; SHIFTF] THEN GEN_TAC);;
e (AP_TERM_TAC);;
e (REWRITE_TAC [GSYM SHIFT_AS_SUBST; PRE; ADD; SUB]);;
e (AP_THM_TAC THEN AP_TERM_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; SHIFTF; LT; SHIFT_0; SUB_0; ADD]);;
let ABS_MODULE_MORPH_LEMMA = top_thm ();;

g `MODULE_MOR LC_SUBST LC_REF (DMOP (SUC 0) LC_SUBST LC_REF LC_SUBST)
     LC_SUBST LC_ABS`;;
e (SIMP_TAC [MODULE_MOR; SELF_MODULE; LC_OPERAD; DMODULE]);;
e (REPEAT GEN_TAC THEN REWRITE_TAC [DMOP; ADD; SUB]);;
e (TRANS_TAC `LC_PROJ (SUBST (LC_LIFT o f) (ABS (LC_LIFT x)))`);;
e (REWRITE_TAC [GSYM ABS_MODULE_MORPH_LEMMA]);;
e (REWRITE_TAC [LC_SUBST_SLC; o_THM; LC_ABS_FACT; LC_PROJ_LCR]);;
e (MATCH_MP_TAC LCR_ABS);;
e (MATCH_MP_TAC LCR_SUBST);;
e (REWRITE_TAC [LCR_REFL; o_THM]);;
e (GEN_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (REWRITE_TAC [LC_REF_FACT; LC_LIFT_PROJ]);;
e (REWRITE_TAC [LC_LIFT_PROJ_RW]);;
e (MATCH_MP_TAC LCR_SUBST);;
e (REWRITE_TAC [LCR_REFL; o_THM; LC_REF_FACT; LC_LIFT_PROJ_RW]);;
e (REWRITE_TAC [LC_SUBST_SLC; o_THM; LC_PROJ_LCR]);;
e (MATCH_MP_TAC LCR_SUBST);;
e (REWRITE_TAC [LCR_REFL]);;
e (CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ));;
e (REWRITE_TAC [LC_ABS_FACT]);;
e (MESON_TAC [LCR_SYM; LC_LIFT_PROJ_RW; LCR_ABS; LCR_REFL]);;
let LC_ABS_MODULE_MOR = top_thm ();;

let LC_APP1_MODULE_MOR = prove
  (`MODULE_ISOM LC_SUBST LC_REF LC_SUBST
     (DMOP (SUC 0) LC_SUBST LC_REF LC_SUBST) LC_APP1 LC_ABS`,
   MESON_TAC [MODULE_ISOM_SYM; LC_APP1_LC_ABS; LC_ABS_LC_APP1;
              MODULE_ISOM; LC_ABS_MODULE_MOR]);;

let LC_EXP = prove
  (`EXP_OPERAD LC_SUBST LC_REF LC_APP1 LC_ABS`,
   REWRITE_TAC [EXP_OPERAD; LC_APP1_MODULE_MOR]);;

g `!x y. LCR (APP x y)
     (SUBST (\n. if n = 0 then y else REF (PRE n)) (APP1 x))`;;
e (REPEAT GEN_TAC THEN MATCH_MP_TAC LCR_TRANS);;
e (EXISTS_TAC `APP (ABS (APP (SHIFT 0 (SUC 0) x) (REF 0))) y`);;
e (CONJ_TAC);;
e (MATCH_MP_TAC LCR_SYM);;
e (MATCH_MP_TAC LCR_APP THEN REWRITE_TAC [LCR_REFL]);;
e (MATCH_MP_TAC LCR_ETA THEN REWRITE_TAC [SLC_ETA_RULES]);;
e (MATCH_MP_TAC LCR_BETA THEN REWRITE_TAC [SLC_BETA_RW; APP1]);;
let LCR_APP_APP1 = top_thm ();;

g `!x y. LC_APP x y =
          LC_SUBST (\n. if n = 0 then y else LC_REF (PRE n)) (LC_APP1 x)`;;
e (REPEAT GEN_TAC);;
e (CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ));;
e (CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `y:LC` LC_PROJ_SURJ));;
e (REWRITE_TAC [o_THM; LC_APP_FACT; LC_APP1_FACT; LC_SUBST_SLC]);;
e (TRANS_TAC
     `LC_PROJ (SUBST (\n. if n = 0 then x else REF (PRE n)) (APP1 x'))`);;
e (REWRITE_TAC [LC_PROJ_LCR; LCR_APP_APP1]);;
e (REWRITE_TAC [LC_PROJ_LCR]);;
e (MATCH_MP_TAC LCR_SUBST);;
e (CONJ_TAC);;
e (REWRITE_TAC [o_THM; LC_REF_FACT]);;
e (MESON_TAC [LCR_SYM; LC_LIFT_PROJ]);;
e (MESON_TAC [LCR_SYM; LC_LIFT_PROJ]);;
let LC_APP_LC_APP1 = top_thm ();;

let EXPM = define
  `(!i. EXPM1 op u h g (REF i) = u i) /\
   (!x. EXPM1 op u h g (ABS x) = g (EXPM1 op u h g x)) /\
   (!x y. EXPM1 op u h g (APP x y) =
    op (\n. if n = 0 then EXPM1 op u h g y else u (PRE n))
       (h (EXPM1 op u h g x)))`;;



(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)

let EXP_MAP = define
  `EXP_MAP op u mop h g (REF i) = u i /\
   EXP_MAP op u mop h g (ABS x) = g (EXP_MAP op u mop h g x) /\
   EXP_MAP op u mop h g (APP x y) =
     mop (\n. if n = 0 then (EXP_MAP op u mop h g y) else u (PRE n))
       (h (EXP_MAP op u mop h g x))`;;


(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)

g `!op u (h:A->A) g a0.
    op (\n. if n = 0 then EXP_MAP op u op h g y else u (PRE n))
      (op (\n. if n = 0 then EXP_MAP op u op h g a1 else u (PRE n))
      (h (EXP_MAP op u op h g a0))) =
      op
      (\n. if n = 0
           then EXP_MAP op u op h g
                (SUBST (\n. if n = 0 then y else REF (PRE n)) a1)
           else u (PRE n))
      (h
      (EXP_MAP op u op h g (SUBST (\n. if n = 0 then y else REF (PRE n)) a0)))`;;
e (GEN_TAC THEN GEN_TAC THEN GEN_TAC THEN GEN_TAC);;
e (MATCH_MP_TAC SLC_INDUCT);;
e (REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SUBST; EXP_MAP]);;

g `!op u (h:A->A) g. EXP_OPERAD op u h g ==>
      !x y. SLC_BETA x y
      ==> EXP_MAP op u op h g x = EXP_MAP op u op h g y`;;
e (REPEAT GEN_TAC THEN REWRITE_TAC [EXP_OPERAD; MODULE_ISOM]);;
e (STRIP_TAC);;
e (SUBGOAL_THEN `MODULE_MOR op u (DMOP (SUC 0) op u op) op (g:A->A)`
    ASSUME_TAC);;
e (ASM_MESON_TAC [MODULE_MOR_INV]);;
e (MATCH_MP_TAC SLC_BETA_INDUCT);;
e (ASM_REWRITE_TAC [EXP_MAP]);;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; EXP_MAP]);;
e (RULE_ASSUM_TAC (REWRITE_RULE [MODULE_MOR; MODULE_DEF; OPERAD_DEF]));;
e (REPEAT (POP_ASSUM MP_TAC));;
e (REPEAT STRIP_TAC);;
e (ASM_REWRITE_TAC []);;
e (COND_CASES_TAC THEN REWRITE_TAC [EXP_MAP]);;
e (SPEC_TAC (`a0:SCL`, `a0:SCL`));;
e (MATCH_MP_TAC SLC_INDUCT);;

SLC_INDUCT;;
 THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; EXP_MAP]);;


(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)

g `!op u mop h g x y. LCR x y ==>
      EXP_MAP op u mop h g x = EXP_MAP op u mop h g y`;;
e (GEN_TAC THEN GEN_TAC THEN GEN_TAC THEN GEN_TAC THEN GEN_TAC);;
e (MATCH_MP_TAC LCR_INDUCT);;
e (REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [EXP_MAP]);;



(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)

g `EXP_OPERAD op u h g ==>
   OPERAD_MOR1 LC_SUSBT LC_REF op u (EXP_MAP op u op h g)`;;

type_of `OPERAD_MOR1 LC_SUBST LC_REF op u`;;
type_of `(EXP_MAP op u op h g)`;;

g `EXP_OPERAD op u mop h g ==>
   MODULE_MOR LC_SUBST LC_REF LC_SUBST
     (PBMOD LC_SUBST LC_REF op u mop EXP_MAP)`;;

 LC_APP1 LC_ABS


       
