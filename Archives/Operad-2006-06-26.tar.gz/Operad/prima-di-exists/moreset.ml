(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)


(* ------------------------------------------------------------------------- *)
(*  IMAGE.                                                                   *)
(* ------------------------------------------------------------------------- *)

let IMAGE_SING = prove
  (`IMAGE f {x} = {f x}`,
   REWRITE_TAC [IMAGE; EXTENSION; IN_SING; IN_ELIM_THM] THEN MESON_TAC []);;

let IMAGE_EMPTY = prove
  (`IMAGE f {} = {}`,
   REWRITE_TAC [IMAGE; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM] THEN MESON_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  PREIMAGE.                                                                *)
(* ------------------------------------------------------------------------- *)

let PREIMAGE = new_definition
  `PREIMAGE (f:A->B) s = { x:A | f x IN s }`;;

let IN_PREIMAGE = prove
  (`!f s. x IN PREIMAGE f s <=> f x IN s`,
   REWRITE_TAC [PREIMAGE; IN_ELIM_THM]);;

let PREIMAGE_UNION = prove
  (`!(f:A->B) s t. PREIMAGE f (s UNION t) = PREIMAGE f s UNION PREIMAGE f t`,
   REWRITE_TAC [PREIMAGE; UNION; IN_UNION; IN_ELIM_THM]);;

let PREIMAGE_INTER = prove
  (`!(f:A->B) s t. PREIMAGE f (s INTER t) = PREIMAGE f s INTER PREIMAGE f t`,
   REWRITE_TAC [PREIMAGE; INTER; IN_INTER; IN_ELIM_THM]);;

let PREIMAGE_DIFF = prove
  (`!(f:A->B) s t. PREIMAGE f (s DIFF t) = PREIMAGE f s DIFF PREIMAGE f t`,
   REWRITE_TAC [PREIMAGE; DIFF; IN_DIFF; IN_ELIM_THM]);;

let PREIMAGE_EMPTY = prove
  (`!(f:A->B). PREIMAGE f {} = {}`,
   REWRITE_TAC [PREIMAGE; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM]);;

let PREIMAGE_SING = prove
  (`!(f:A->B) a. PREIMAGE f {a} = { x:A | f x = a }`,
   REWRITE_TAC [PREIMAGE; IN_SING]);;

let PREIMAGE_o = prove
  (`!f g s. PREIMAGE (f o g) s = PREIMAGE g (PREIMAGE f s)`,
   REWRITE_TAC [PREIMAGE; o_DEF; EXTENSION; IN_ELIM_THM]);;


(* ------------------------------------------------------------------------- *)
(*  Misc.                                                                    *)
(* ------------------------------------------------------------------------- *)

let set_of_list_APPEND = prove
  (`!l1 l2. set_of_list (APPEND l1 l2) =
            (set_of_list l1) UNION (set_of_list l2)`,
   LIST_INDUCT_TAC THEN REWRITE_TAC [APPEND; set_of_list; UNION] THEN
   SET_TAC []);;

let SING_INJ = prove
  (`!x y. {x} = {y} <=> x = y`,
   GEN_TAC THEN GEN_TAC THEN EQ_TAC THEN
   SIMP_TAC [EXTENSION; IN_SING] THEN MESON_TAC []);;
