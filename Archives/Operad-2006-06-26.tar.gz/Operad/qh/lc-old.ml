(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "/home/maggesi/Trees/HOL/hol_light/Permutation/nummax.ml";;
needs "/home/maggesi/Trees/HOL/hol_light/Permutation/morelist.ml";;
needs "/home/maggesi/Trees/HOL/hol_light/Operad/moreset.ml";;

let NUM_CASES_TAC tm =
  DISJ_CASES_THEN2 SUBST_ALL_TAC (CHOOSE_THEN SUBST_ALL_TAC)
    (SPEC tm num_CASES);;


let ASM_ARITH_TAC =
  POP_ASSUM_LIST (MP_TAC o end_itlist CONJ) THEN ARITH_TAC;;


(* ------------------------------------------------------------------------- *)
(*  Basic defs                                                               *)
(* ------------------------------------------------------------------------- *)

let SLC_INDUCT, SLC_RECURSION = define_type
  "SLC = REF num
       | APP SLC SLC
       | ABS SLC";;

let FV = new_recursive_definition SLC_RECURSION
  `FV (REF n) = {n} /\
   FV (APP x y) = FV x UNION FV y /\
   FV (ABS x) = PREIMAGE SUC (FV x)`;;

let FV' = new_recursive_definition SLC_RECURSION
  `FV' k (REF n) = (if n < k then {} else {n - k}) /\
   FV' k (APP x y) = FV' k x UNION FV' k y /\
   FV' k (ABS x) = FV' (SUC k) x`;;

let SHIFT = new_recursive_definition SLC_RECURSION
  `SHIFT k n (REF i) = REF (if i < k then i else n + i) /\
   SHIFT k n (APP x y) = APP (SHIFT k n x) (SHIFT k n y) /\
   SHIFT k n (ABS x) = ABS (SHIFT (SUC k) n x)`;;

let SHIFTF = new_definition
  `SHIFTF k f i = if i < k then REF i else SHIFT 0 k (f (i - k))`;;

let SUBST = new_recursive_definition SLC_RECURSION
  `SUBST f (REF i) = f i /\
   SUBST f (APP x y) = APP (SUBST f x) (SUBST f y) /\
   SUBST f (ABS x) = ABS (SUBST (SHIFTF (SUC 0) f) x)`;;


(* ------------------------------------------------------------------------- *)
(*  FV, FV'                                                                  *)
(* ------------------------------------------------------------------------- *)

g `!x k. FV' k x = PREIMAGE ((+) k) (FV x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT CONJ_TAC THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV; FV'; PREIMAGE_UNION; PREIMAGE_SING]);;
e (COND_CASES_TAC THEN
   REWRITE_TAC [IN_SING; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM] THEN
   POP_ASSUM MP_TAC THEN ARITH_TAC);;
e (FIRST_X_ASSUM (fun th -> REWRITE_TAC [GSYM PREIMAGE_o; th]) THEN
   AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_DEF; ADD]);;
let FV'_FV = top_thm ();;

let FV_FV' = prove
  (`!x. FV x = FV' 0 x`,
   GEN_TAC THEN REWRITE_TAC [FV'_FV; PREIMAGE; ADD] THEN SET_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  SHIFT                                                                    *)
(* ------------------------------------------------------------------------- *)

let SHIFT_0 = prove
  (`!x k. SHIFT k 0 x = x`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; ADD] THEN COND_CASES_TAC
   THEN REWRITE_TAC []);;

g `!x h k n m. h <= k ==> SHIFT h n (SHIFT k m x) =
                          SHIFT (k + n) m (SHIFT h n x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (SUBST1_TAC (ARITH_RULE `SUC (k + n) = SUC k + n`));;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_REWRITE_TAC [LE_SUC]);;
let LE_SHIFT_COMM = top_thm ();;

g `!x h k n m. n + h <= k ==> SHIFT k m (SHIFT h n x) =
                              SHIFT h n (SHIFT (k - n) m x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN 
   REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (SUBGOAL_THEN `SUC (k - n) = SUC k - n` SUBST1_TAC);;
e (ASM_ARITH_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_ARITH_TAC);;
let SHIFT_COMM2 = top_thm ();;

g `!n m x h k. k <= h /\ h <= k + m
               ==> SHIFT h n (SHIFT k m x) = SHIFT k (m + n) x`;;
e (GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_ARITH_TAC);;
let SHIFT_SHIFT = top_thm ();;

(* Caso particolare del precedente. *)
let SHIFT_SHIFT_1 = prove
  (`!n m x k. SHIFT k n (SHIFT k m x) = SHIFT k (m + n) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SHIFT] THEN
   AP_TERM_TAC THEN ARITH_TAC);;

let SHIFT_SHIFT_2 = prove
  (`!n m x k. k <= m ==> SHIFT k n (SHIFT 0 m x) = SHIFT 0 (m + n) x`,
   REPEAT STRIP_TAC THEN MATCH_MP_TAC SHIFT_SHIFT THEN
   ASM_REWRITE_TAC [ADD; LE_0]);;

let SHIFT_SHIFT_3 = prove
  (`!n x k. SHIFT k n (SHIFT 0 k x) = SHIFT 0 (k + n) x`,
   MESON_TAC [SHIFT_SHIFT_2; LE_REFL]);;

g `!n x k. FV' (n + k) (SHIFT k n x) = FV' k x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FV'; SHIFT]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [] THEN
   COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (n + k) = n + SUC k`]);;
let FV'_SHIFT = top_thm ();;

g `!n x k. FV' k (SHIFT 0 k x) = FV' 0 x`;;
e (REPEAT GEN_TAC THEN MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `FV' (k + 0) (SHIFT 0 k x)`);;
e (CONJ_TAC THENL [REWRITE_TAC [ADD_0]; REWRITE_TAC [FV'_SHIFT]]);;
let FV'_SHIFT_0 = top_thm ();;

g `!f h k. SHIFTF h (SHIFTF k f) = SHIFTF (h + k) f`;;
e (REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF; FUN_EQ_THM]);;
e (GEN_TAC THEN ASM_CASES_TAC `x < h` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `x < h + k` (fun th -> REWRITE_TAC [th]) THEN ASM_ARITH_TAC);;
e (ASM_CASES_TAC `x < h + k` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `x - h < k` (fun th -> REWRITE_TAC [th; SHIFT])
   THEN TRY AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(x - h < k)` (fun th -> REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [SHIFT_SHIFT_1]);;
e (REWRITE_TAC [ADD_AC]);;
e (AP_TERM_TAC THEN AP_TERM_TAC THEN ASM_ARITH_TAC);;
let SHIFTF_SHIFTF = top_thm ();;

g `!n x. PREIMAGE (\i. n + i) (FV (SHIFT 0 n x)) = FV x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REWRITE_TAC [FV; SHIFT] THEN
   REPEAT STRIP_TAC);;
e (REWRITE_TAC [LT; PREIMAGE_SING]);;
e (REWRITE_TAC [EXTENSION; IN_SING; IN_ELIM_THM]);;
e (ARITH_TAC);;
e (ASM_REWRITE_TAC [PREIMAGE_UNION]);;
e (ASM_REWRITE_TAC [GSYM PREIMAGE_o]);;

g `!n x k. FV' k (SHIFT k n x) = IMAGE (\i. n + i) (FV' k x)`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV'; SHIFT; IMAGE_UNION]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [IMAGE_EMPTY]);;
e (COND_CASES_TAC THEN REWRITE_TAC [IMAGE_SING; SING_INJ] THEN
   ASM_ARITH_TAC);;
let FV'_SHIFT_IMAGE = top_thm ();;

let FV_SHIFT_0 = prove
  (`!n x. FV (SHIFT 0 n x) = IMAGE (\i. n + i) (FV x)`,
   REWRITE_TAC [FV_FV'; FV'_SHIFT_IMAGE]);;

g `!f k i. FV (SHIFTF k f i) =
           if i < k then {i} else IMAGE (\i. k + i) (FV (f (i - k)))`;;
e (REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF] THEN COND_CASES_TAC THEN
   REWRITE_TAC [FV; FV_SHIFT_0]);;
let FV_SHIFTF = top_thm ();;


(* ------------------------------------------------------------------------- *)
(*  SUBST                                                                    *)
(* ------------------------------------------------------------------------- *)


g `!x f. FV (SUBST f x) = {n | ?m. m IN FV x /\ n IN FV (f m)}`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; FV] THEN REPEAT GEN_TAC);;
e (SET_TAC []);;
e (SET_TAC []);;
e (REWRITE_TAC [FV_SHIFTF; ADD; ETA_AX; IN_PREIMAGE; SUB]);;
e (REWRITE_TAC [ARITH_RULE `m < SUC 0 <=> m = 0`]);;
e (REWRITE_TAC [EXTENSION; IN_PREIMAGE; IN_ELIM_THM]);;
e (GEN_TAC THEN EQ_TAC THEN STRIP_TAC);;
e (EXISTS_TAC `PRE m`);;
e (NUM_CASES_TAC `m:num` THEN
   RULE_ASSUM_TAC (REWRITE_RULE [IN_SING; NOT_SUC; IN_IMAGE;
                                 PRE; ADD; SUC_INJ]));;
e (ASM_MESON_TAC []);;
e (ASM_REWRITE_TAC [PRE]);;
e (SET_TAC []);;
e (EXISTS_TAC `SUC m` THEN ASM_REWRITE_TAC [NOT_SUC]);;
e (REWRITE_TAC [IN_IMAGE; ADD; SUC_INJ; PRE]);;
e (SET_TAC []);;
let FV_SUBST = top_thm ();;

g `!x n. SUBST (SHIFTF n REF) x = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF_SHIFTF; ADD]);;
e (REWRITE_TAC [SHIFTF]);;
e (COND_CASES_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
let SUBST_REF_UNIT_L = top_thm ();;

g `!n x f k. SHIFT k n (SUBST f x) = SUBST (SHIFTF n f) x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [SUBST; SHIFT]);;
e (REWRITE_TAC [SHIFTF]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT]);;

e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC [o_ASSOC]);;
e (SUBGOAL_THEN `SUC h <= SUC k` ASSUME_TAC);;
e (ASM_REWRITE_TAC [LE_SUC]);;
e (ASM_SIMP_TAC [o_ASSOC]);;
e (REPEAT (AP_TERM_TAC ORELSE AP_THM_TAC));;
e (REWRITE_TAC [FUN_EQ_THM; o_DEF]);;
e (GEN_TAC);;
e (REWRITE_TAC [BUMP_SHIFT; ADD_SUC; ADD_0;
                MATCH_MP LE_SHIFT_COMM (ASSUME `h <= k`)]);;
let SHIFT_SUBST = top_thm ();;


g `!x f h k. SUBST (SHIFTF (h + k) f) (SHIFT h k x) =
             SHIFT h k (SUBST (SHIFTF h f) x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFT; SHIFTF_SHIFTF; ADD]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFTF]);;
e (SUBGOAL_THEN `a < h + k` (fun th -> ASM_REWRITE_TAC [th; SHIFT]));;
e (ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(k + a < h + k)` (fun th -> ASM_REWRITE_TAC [th; SHIFT]));;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [SHIFT_SHIFT_3]);;
e (REPEAT AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (AP_TERM_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (h + k) = SUC h + k`]);;
let SHIFT_SUBST_LEMMA1 = top_thm ();;

let SHIFTF_0 = prove
  (`!f. SHIFTF 0 f = f`,
   REWRITE_TAC [FUN_EQ_THM; SHIFTF; SHIFT_0; LT; SUB_0]);;

let SHIFT_SUBST_LEMMA2 = prove
  (`!x f k. SUBST (SHIFTF k f) (SHIFT 0 k x) = SHIFT 0 k (SUBST f x)`,
   MESON_TAC [ADD; SHIFTF_0; SHIFT_SUBST_LEMMA1]);;

let SHIFTF_SUBST = prove
  (`!f g k i. SUBST (SHIFTF k f) (SHIFTF k g i) =
              SHIFTF k (SUBST f o g) i`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF] THEN COND_CASES_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF; o_DEF; SHIFT_SUBST_LEMMA2]);;

let SUBST_SUBST_LEMMA = prove
  (`!f g x k. SUBST (SHIFTF k f) (SUBST (SHIFTF k g) x) =
              SUBST (SHIFTF k (SUBST f o g)) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF_SHIFTF; ADD; o_DEF; SHIFTF_SUBST]);;

let SUBST_SUBST = prove
  (`!f g x. SUBST f (SUBST g x) = SUBST (SUBST f o g) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SUBST; o_DEF; SUBST_SUBST_LEMMA]);;
