(* -*- holl -*- *)

(* Possibly one of the most stupid example of a quotient: just to make
   a test. *)

let R = new_definition
  `R n m <=> (n = 0 /\ m = 0) \/ ~(n = 0 \/ m = 0)`;;

(* R is an equivalent relation. *)
let R_REFL = prove
  (`!n. R n n`,
   REWRITE_TAC [R] THEN MESON_TAC []);;

let R_SYM = prove
  (`!n m. R n m <=> R m n`,
   REWRITE_TAC [R] THEN MESON_TAC []);;

let R_TRANS = prove
  (`!n m p. R n m /\ R m p ==> R n p`,
   REWRITE_TAC [R] THEN MESON_TAC []);;

let Z2_TYBIJ =
  define_quotient_type "Z2" ("MK_Z2","DEST_Z2") `R`;;

let z2_lift_function =
  lift_function (snd Z2_TYBIJ) (R_REFL,R_TRANS);;

(* Definition of opposite. *)
let Z2_OPP_ = new_definition
  `Z2_OPP_ n = if n = 0 then 1 else 0`;;

let Z2_OPP_R = prove
  (`!n m. R n m ==> R (Z2_OPP_ n) (Z2_OPP_ m)`,
   REWRITE_TAC [R; Z2_OPP_] THEN MESON_TAC []);;

let Z2_OPP, Z2_OPP_TH = z2_lift_function "Z2_OPP" Z2_OPP_R;;

(* Something must be wrong here since n occurs
   with "two different bindings". *)
(*
val ( Z2_OPP ) : thm =
  |- Z2_OPP n = MK_Z2 (\u. ?n. R (Z2_OPP_ n) u /\ DEST_Z2 n n)
val ( Z2_OPP_TH ) : thm = |- MK_Z2 (R (Z2_OPP_ n)) = Z2_OPP (MK_Z2 (R n))
*)


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let Z2_PROJ = new_definition
  `Z2_PROJ n = MK_Z2 (R n)`;;

let TRANS_TAC tm = MATCH_MP_TAC EQ_TRANS THEN EXISTS_TAC tm THEN CONJ_TAC;;

let Z2_PROJ_R = prove
  (`!x y. Z2_PROJ x = Z2_PROJ y <=> R x y`,
   REPEAT GEN_TAC THEN TRANS_TAC `R x = R y` THENL
   [REWRITE_TAC [Z2_PROJ] THEN MESON_TAC [fst Z2_TYBIJ; snd Z2_TYBIJ];
    MESON_TAC [FUN_EQ_THM; R_REFL; R_TRANS; R_SYM]]);;

(*
e (REPEAT GEN_TAC THEN TRANS_TAC `R x = R y` THENL
   [REWRITE_TAC [Z2_PROJ] THEN MESON_TAC [fst Z2_TYBIJ; snd Z2_TYBIJ];
    EQ_TAC THENL
    [MESON_TAC [R_REFL];
     DISCH_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN
     ASM_MESON_TAC [R_TRANS; R_SYM]]]);;
*)

let MK_Z2_SURJ = prove
  (`!a. ?p. MK_Z2 p = a /\ (?x. p = R x)`,
   MESON_TAC [fst Z2_TYBIJ; snd Z2_TYBIJ]);;

let Z2_PROJ_SURJ = prove
  (`!y. ?x. Z2_PROJ x = y`,
   REWRITE_TAC [Z2_PROJ] THEN
   MESON_TAC [fst Z2_TYBIJ; snd Z2_TYBIJ]);;

let Z2_LIFT = new_definition
  `Z2_LIFT y = (@x. Z2_PROJ x = y)`;;

let Z2_PROJ_LIFT = prove
  (`!y. Z2_PROJ (Z2_LIFT y) = y`,
   REWRITE_TAC [Z2_LIFT] THEN MESON_TAC [SELECT_AX; Z2_PROJ_SURJ]);;

g `!x. R (Z2_LIFT (Z2_PROJ x)) x`;;
e (REWRITE_TAC [Z2_LIFT] THEN GEN_TAC);;
e (REWRITE_TAC [Z2_PROJ_R]);;
e (MESON_TAC [SELECT_AX; R_REFL]);;
