(* -*- holl -*- *)

let ASSOCIATIVITY = new_definition
  `!op:A->A->A. ASSOCIATIVITY op <=>
                  (!x y z. op (op x y) z = op x (op y z))`;;

let COMMUTATIVITY = new_definition
  `!op:A->A->A. COMMUTATIVITY op <=> (!x y. op x y = op y x)`;;

let IDENTITY_L = new_definition
  `!(op:A->A->A) (u:A). IDENTITY_L op u <=> (!x. op u x = x)`;;

let IDENTITY_R = new_definition
  `!(op:A->A->A) (u:A). IDENTITY_R op u <=> (!x. op x u = x)`;;

let IDENTITY_DEF = new_definition
  `!op u. IDENTITY op u <=> IDENTITY_L op u /\ IDENTITY_R op u`;;

let IDENTITY = prove
  (`!(op:A->A->A) (u:A).
       IDENTITY op u <=> (!x. op x u = x) /\ (!x. op u x = x)`,
   REWRITE_TAC [IDENTITY_DEF; IDENTITY_L; IDENTITY_R] THEN ITAUT_TAC);;

let INVERSE_L = new_definition
  `!(op:A->A->A) (u:A) (iv:A->A).
      INVERSE_L op u iv <=> (!x. op (iv x) x = u)`;;

let INVERSE_R = new_definition
  `!(op:A->A->A) (u:A) (iv:A->A).
      INVERSE_R op u iv <=> (!x. op x (iv x) = u)`;;

let INVERSE_DEF = new_definition
  `!op u iv. INVERSE op u iv <=> INVERSE_L op u iv /\ INVERSE_R op u iv`;;

let INVERSE = prove
  (`!(op:A->A->A) (u:A) (iv:A->A).
      INVERSE op u iv <=> (!x. op (iv x) x = u) /\ (!x. op x (iv x) = u)`,
   REWRITE_TAC [INVERSE_DEF; INVERSE_L; INVERSE_R] THEN ITAUT_TAC);;

(* ------------------------------------------------------------------------- *)
(*  Distributivity.                                                          *)
(* ------------------------------------------------------------------------- *)

let DISTRIBUTIVITY_L = new_definition
  `!add mul. DISTRIBUTIVITY_L add mul <=>
               (!x y z. mul x (add y z) = add (mul x y) (mul x z))`;;

let DISTRIBUTIVITY_R = new_definition
  `!add mul. DISTRIBUTIVITY_R add mul <=>
               (!x y z. mul (add y z) x = add (mul y x) (mul z x))`;;

let DISTRIBUTIVITY_DEF = new_definition
  `!add mul. DISTRIBUTIVITY add mul <=>
	       DISTRIBUTIVITY_L add mul /\ DISTRIBUTIVITY_R add mul`;;

let DISTRIBUTIVITY = prove
  (`!add mul. DISTRIBUTIVITY add mul <=>
                (!x y z. mul x (add y z) = add (mul x y) (mul x z)) /\
                (!x y z. mul (add y z) x = add (mul y x) (mul z x))`,
   REWRITE_TAC [DISTRIBUTIVITY_DEF; DISTRIBUTIVITY_L; DISTRIBUTIVITY_R] THEN
   ITAUT_TAC);;

(* ------------------------------------------------------------------------- *)
(*  Monoids.                                                                 *)
(* ------------------------------------------------------------------------- *)

let MONOID_DEF = new_definition
  `!op u. MONOID op u <=> ASSOCIATIVITY op /\ IDENTITY op u`;;

let MONOID = prove 
  (`!op u. MONOID op u <=>
             (!x. op u x = x) /\
             (!x. op x u = x) /\
             (!x y z. op (op x y) z = op x (op y z))`,
   REPEAT GEN_TAC THEN
   REWRITE_TAC [MONOID_DEF; ASSOCIATIVITY; IDENTITY] THEN
   EQ_TAC THEN STRIP_TAC THEN ASM_REWRITE_TAC [] THEN
   ASM_MESON_TAC []);;

(* ------------------------------------------------------------------------- *)
(*  Commutative Monoids.                                                     *)
(* ------------------------------------------------------------------------- *)

let CMONOID_DEF = new_definition
  `!op u. CMONOID op u <=>
            ASSOCIATIVITY op /\ COMMUTATIVITY op /\ IDENTITY op u`;;

let CMONOID = prove 
  (`!op u. CMONOID op u <=>
             (!x. op u x = x) /\
             (!x. op x u = x) /\
             (!x y. op y x = op x y) /\
             (!x y z. op (op x y) z = op x (op y z)) /\
             (!x y z. op x (op y z) = op y (op x z))`,
   REPEAT GEN_TAC THEN REWRITE_TAC [CMONOID_DEF; ASSOCIATIVITY;
                                 COMMUTATIVITY; IDENTITY] THEN
   EQ_TAC THEN STRIP_TAC THEN ASM_REWRITE_TAC [] THEN
   ASM_MESON_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  Abelian Groups.                                                          *)
(* ------------------------------------------------------------------------- *)

let ABGROUP_DEF = new_definition
  `!add zero opp.
      ABGROUP add zero opp <=>
        ASSOCIATIVITY add /\ COMMUTATIVITY add /\
        IDENTITY add zero /\ INVERSE add zero opp`;;

let ABGROUP = prove (* jjda *)
  (`!add zero opp.
      ABGROUP add zero opp <=>
        (!x. add zero x = x) /\
        (!x. add x zero = x) /\
        (!x. add (opp x) x = zero) /\
        (!x. add x (opp x) = zero) /\
        (!x y. add (opp x) (add x y) = y) /\
        (!x y. add x (add (opp x) y) = y) /\
        (!x y. add y x = add x y) /\
        (!x y z. add (add x y) z = add x (add y z)) /\
        (!x y z. add x (add y z) = add y (add x z))`,
   REPEAT GEN_TAC THEN
   REWRITE_TAC [ABGROUP_DEF; ASSOCIATIVITY;
                COMMUTATIVITY; IDENTITY; INVERSE] THEN
   EQ_TAC THEN STRIP_TAC THEN ASM_REWRITE_TAC [] THEN ASM_MESON_TAC []);;

(* ------------------------------------------------------------------------- *)
(*  Commutative rings.                                                       *)
(* ------------------------------------------------------------------------- *)

let CRING_DEF = new_definition
  `!add zero opp mul unit.
      CRING add zero opp mul unit <=>
        ASSOCIATIVITY add /\ COMMUTATIVITY add /\
	IDENTITY add zero /\ INVERSE add zero opp /\
        ASSOCIATIVITY mul /\ COMMUTATIVITY mul /\
	IDENTITY mul unit /\ DISTRIBUTIVITY add mul`;;

let CRING_ABGROUP = prove
  (`!add zero opp mul unit.
      CRING add zero opp mul unit ==> ABGROUP add zero opp`,
   SIMP_TAC [CRING_DEF; ABGROUP_DEF]);;

let CRING_CMONOID = prove
  (`!add zero opp mul unit.
      CRING add zero opp mul unit ==> CMONOID mul unit`,
   SIMP_TAC [CRING_DEF; CMONOID_DEF]);;

let CRING = time prove 
  (`!add zero opp mul (unit:A).
      CRING add zero opp mul unit <=>
        (!x. add zero x = x) /\
        (!x. add x zero = x) /\
        (!x. add (opp x) x = zero) /\
        (!x. add x (opp x) = zero) /\
        (!x y. add (opp x) (add x y) = y) /\
        (!x y. add x (add (opp x) y) = y) /\
        (!x y. add y x = add x y) /\
        (!x y z. add (add x y) z = add x (add y z)) /\
        (!x y z. add x (add y z) = add y (add x z)) /\
        (!x. mul unit x = x) /\
        (!x. mul x unit = x) /\
        (!x y. mul y x = mul x y) /\
        (!x y z. mul (mul x y) z = mul x (mul y z)) /\
        (!x y z. mul x (mul y z) = mul y (mul x z)) /\
        (!x y z. mul x (add y z) = add (mul x y) (mul x z)) /\
        (!x y z. mul (add y z) x = add (mul y x) (mul z x))`,
   REPEAT GEN_TAC THEN EQ_TAC THENL
   [DISCH_TAC; SIMP_TAC [CRING_DEF; ASSOCIATIVITY; COMMUTATIVITY;
                       IDENTITY; INVERSE; DISTRIBUTIVITY]] THEN
   SUBGOAL_THEN `ABGROUP add (zero:A) opp`
     (fun th -> REWRITE_TAC [REWRITE_RULE [ABGROUP] th]) THENL
   [MATCH_MP_TAC CRING_ABGROUP THEN ASM_MESON_TAC []; ALL_TAC] THEN
   let rw = REWRITE_RULE [CRING_DEF; ASSOCIATIVITY; COMMUTATIVITY;
                          IDENTITY; INVERSE; DISTRIBUTIVITY]
   in
   FIRST_X_ASSUM (STRIP_ASSUME_TAC o rw) THEN
   ASM_REWRITE_TAC [] THEN ASM_MESON_TAC []);;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

(*
let GROUP_L_DEF = new_definition
  `!op u iv. GROUP_L op u iv <=>
      ASSOCIATIVITY op /\ IDENTITY_L op u /\ INVERSE_L op u iv`;;

let GROUP_R_DEF = new_definition
  `!op u iv. GROUP_R op u iv <=>
      ASSOCIATIVITY op /\ IDENTITY_R op u /\ INVERSE_R op u iv`;;

let GROUP_DEF = new_definition
  `!op u iv. GROUP op u iv <=>
      ASSOCIATIVITY op /\ IDENTITY op u /\ INVERSE op u iv`;;
*)


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let AC_EQS = new_definition
  `!op:A->A->A. AC_EQS op <=>
		(!x y. op y x = op x y) /\
                (!x y z. op (op x y) z = op x (op y z)) /\
                (!x y z. op x (op y z) = op y (op x z))`;;

let AC_THM = prove
  (`!op:A->A->A. AC_EQS op <=> ASSOCIATIVITY op /\ COMMUTATIVITY op`,
   REWRITE_TAC [AC_EQS; ASSOCIATIVITY; COMMUTATIVITY] THEN MESON_TAC []);;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

