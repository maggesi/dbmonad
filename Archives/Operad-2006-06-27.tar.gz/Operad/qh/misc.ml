let EL0 = define
  `EL0 x n [] = x /\
   EL0 x 0 (CONS h t) = h /\
   EL0 x (SUC n) (CONS h t) = EL0 x n t`;;

let MAPII_DX = prove
  (`!f l1 l2. MAPII (\x y. f y) l1 l2 = MAP f (TRUNCATE (LENGTH l1) l2)`,
   GEN_TAC THEN LIST_INDUCT_TAC THEN
   REWRITE_TAC [LENGTH; TRUNCATE; MAP; MAPII] THEN
   LIST_INDUCT_TAC THEN ASM_REWRITE_TAC [MAPII; TRUNCATE; MAP]);;

let LENGTH_TRUNCATE = prove
  (`!n l. LENGTH (TRUNCATE n l) = MIN (LENGTH l) n`,
   INDUCT_TAC THEN LIST_INDUCT_TAC THEN
   ASM_REWRITE_TAC [TRUNCATE; LENGTH; MIN_0; SUC_MIN]);;

let TRUNCATE_REPLICATE = prove
  (`!n m x. TRUNCATE m (REPLICATE n x) = REPLICATE (MIN m n) x`,
   INDUCT_TAC THEN REWRITE_TAC [REPLICATE; TRUNCATE; MIN_0] THEN
   INDUCT_TAC THEN
   ASM_REWRITE_TAC [REPLICATE; TRUNCATE; GSYM SUC_MIN; MIN_0]);;

let MAP_REPLICATE = prove
  (`!f x n. MAP f (REPLICATE n x) = REPLICATE n (f x)`,
   GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
   ASM_REWRITE_TAC [MAP; REPLICATE]);;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let SUMNUM_DEF = new_definition
  `SUMNUM l = ITLIST (+) l 0`;;

let SUMNUM_NIL = prove
  (`SUMNUM [] = 0`,
    REWRITE_TAC [SUMNUM_DEF; ITLIST]);;

let SUMNUM_CONS = prove
  (`!h t. SUMNUM (CONS h t) = h + SUMNUM t`,
    REWRITE_TAC [SUMNUM_DEF; ITLIST]);;

let SUMNUM = prove
  (`SUMNUM [] = 0 /\
    (!h t. SUMNUM (CONS h t) = h + SUMNUM t)`,
    REWRITE_TAC [SUMNUM_NIL; SUMNUM_CONS]);;

let SUMNUM_APPEND = prove
  (`!l1 l2. SUMNUM (APPEND l1 l2) = SUMNUM l1 + SUMNUM l2`,
   LIST_INDUCT_TAC THEN ASM_REWRITE_TAC [APPEND; SUMNUM; ADD; ADD_AC]);;

let LENGTH_FLATTEN = prove
  (`!l. LENGTH (FLATTEN l) = SUMNUM (MAP LENGTH l)`,
   LIST_INDUCT_TAC THEN
   ASM_REWRITE_TAC [FLATTEN; MAP; LENGTH; LENGTH_APPEND; SUMNUM]);;

let SUMNUM_TRUNCATE0_NIL = prove
  (`!m n. SUMNUM (TRUNCATE0 m n []) = m * n`,
   GEN_TAC THEN INDUCT_TAC THEN
   ASM_REWRITE_TAC [TRUNCATE0; SUMNUM; MULT_0; MULT_SUC]);;



(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)






let VEC_LIST_THM = new_type_definition "VEC" ("LIST_VEC", "VEC_LIST")
    (prove (`?x. ALL (\n. n < FST x) (SND x)`,
	    EXISTS_TAC `(0,[]:num list)` THEN REWRITE_TAC [ALL]));;

let VGENUS = new_definition
  `VGENUS v = FST (VEC_LIST v)`;;

let VLENGTH = new_definition
  `VLENGTH v = 


let TAILN = define
  `TAILN 0 l = l /\
   TAILN n [] = [] /\
   TAILN (SUC n) (CONS h t) = TAILN n t`;;

g `!l1 l2 l3. MAPII f (APPEND l1 l2) l3 =
     APPEND (MAPII f l1 (TRUNCATE (LENGTH l1) l3))
            (MAPII f l2 (TAILN (LENGTH l1) l3))`;;
e (LIST_INDUCT_TAC THEN
   REWRITE_TAC [LENGTH; TAILN; TRUNCATE; MAPII; APPEND] THEN
   GEN_TAC THEN LIST_CASES_TAC THEN
   ASM_REWRITE_TAC [TAILN; TRUNCATE; MAPII; APPEND]);;
let MAPII_APPEND_SX = top_thm ();;
