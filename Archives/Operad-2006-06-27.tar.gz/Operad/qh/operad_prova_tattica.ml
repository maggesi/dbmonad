(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)


(* ------------------------------------------------------------------------- *)
(*  Operads.                                                                 *)
(* ------------------------------------------------------------------------- *)

let OPERAD_DEF = new_definition
  `!(op:(num->A)->A->A) (i:num->A).
     OPERAD op i <=>
       (!f n. op f (i n) = f n) /\
       (!x. op i x = x) /\
       (!f g x. op g (op f x) = op (\n. op g (f n)) x)`;;

let OPERAD_RW_RULES : thm -> thm =
  let OPERAD_IMP = prove
    (`OPERAD op i ==>
        (!f n. op f (i n) = f n) /\
        (!x. op i x = x) /\
        (!f g x. op g (op f x) = op (\n. op g (f n)) x)`,
     REWRITE_TAC [OPERAD_DEF])
  in
  MATCH_MP OPERAD_IMP;;

let OPERAD_RW_TAC : thm_tactic =
  fun th -> REWRITE_TAC [OPERAD_RW_RULES th];;

let ASM_OPERAD_RW_TAC : tactic =
  POP_ASSUM_LIST (REWRITE_TAC o mapfilter OPERAD_RW_RULES);;

(* Example: operad of lists. *)
(***********************************
needs "/home/maggesi/Trees/HOL/hol_light/Permutation/morelist.ml";;

g `OPERAD FLATMAP (\n:num. [n])`;;
e (REWRITE_TAC [OPERAD_DEF; FLATMAP; APPEND_NIL]);;
e (CONJ_TAC);;
e (LIST_INDUCT_TAC THEN ASM_REWRITE_TAC [FLATMAP; APPEND]);;
e (GEN_TAC THEN GEN_TAC THEN LIST_INDUCT_TAC THEN
   ASM_REWRITE_TAC [FLATMAP; FLATMAP_APPEND]);;
let LIST_OPERAD = top_thm ();;
*************************************)


let OPERAD_MOR = new_definition
  `OPERAD_MOR op1 i1 op2 i2 h <=>
     OPERAD op1 i1 /\ OPERAD op2 i2 /\
     (!n. h (i1 n) = i2 n) /\
     (!f x. h (op1 f x) = op2 (h o f) (h x))`;;

let OPERAD_MOR_RW_RULES : thm -> thm =  
  let OPERAD_MOR_IMP = prove
    (`OPERAD_MOR op1 i1 op2 i2 h ==>
        OPERAD op1 i1 /\ OPERAD op2 i2 /\
        (!f n. op1 f (i1 n) = f n) /\
        (!x. op1 i1 x = x) /\
        (!f g x. op1 g (op1 f x) = op1 (\n. op1 g (f n)) x) /\
        (!f n. op2 f (i2 n) = f n) /\
        (!x. op2 i2 x = x) /\
        (!f g x. op2 g (op2 f x) = op2 (\n. op2 g (f n)) x) /\
        (!n. h (i1 n) = i2 n) /\
        (!f x. h (op1 f x) = op2 (h o f) (h x))`,
     SIMP_TAC [OPERAD_MOR; OPERAD_DEF])
  in
  MATCH_MP OPERAD_MOR_IMP;;

let ASM_OPERAD_MOR_RW_TAC : tactic =
  POP_ASSUM_LIST (REWRITE_TAC o mapfilter OPERAD_MOR_RW_RULES);;

let OPERAD_MOR_ID = prove
  (`!op i. OPERAD op i ==> OPERAD_MOR op i op i (\x. x)`,
   REWRITE_TAC [OPERAD_MOR; o_DEF; ETA_AX]);;


g `!op1 i1 op2 i2 op3 i3 h g.
    OPERAD_MOR op1 i1 op2 i2 h /\
    OPERAD_MOR op2 i2 op3 i3 g ==>
    OPERAD_MOR op1 i1 op3 i3 (g o h)`;;
e (REPEAT STRIP_TAC THEN REWRITE_TAC [OPERAD_MOR; o_DEF]);;
e (ASM_OPERAD_MOR_RW_TAC);;
e (REWRITE_TAC [o_DEF]);;

   SIMP_TAC [OPERAD_MOR] THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [o_THM; o_ASSOC]);;

let OPERAD_MOR_o = prove
  (`!op1 i1 op2 i2 op3 i3 h g.
    OPERAD_MOR op1 i1 op2 i2 h /\
    OPERAD_MOR op2 i2 op3 i3 g ==>
    OPERAD_MOR op1 i1 op3 i3 (g o h)`,
   SIMP_TAC [OPERAD_MOR] THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [o_THM; o_ASSOC]);;


(* ------------------------------------------------------------------------- *)
(*  Modules.                                                                 *)
(* ------------------------------------------------------------------------- *)

let MODULE_DEF = new_definition
  `!(op:(num->A)->A->A) (i:num->A) (mop:(num->A)->B->B).
     MODULE op i mop <=>
       OPERAD op i /\
       (!x. mop i x = x) /\
       (!f g x. mop g (mop f x) = mop (\n. op g (f n)) x)`;;

let SELF_MODULE = prove
  (`!op i mop. MODULE op i op <=> OPERAD op i`,
   MESON_TAC [OPERAD_DEF; MODULE_DEF]);;

let SELF_MODULE = prove
  (`!op i mop. MODULE op i op <=> OPERAD op i`,
   REWRITE_TAC [OPERAD_DEF; MODULE_DEF] THEN REPEAT STRIP_TAC THEN
   EQ_TAC THEN REPEAT STRIP_TAC THEN ASM_REWRITE_TAC []);;

let MODULE_MOR = new_definition
  `MODULE_MOR op i mop1 mop2 h <=>
    MODULE op i mop1 /\
    MODULE op i mop2 /\
    (!f x. h (mop1 f x) = mop2 f (h x))`;;

let MODULE_MOR_ID = prove
  (`MODULE op i mop <=> MODULE_MOR op i mop mop (\x. x)`,
    REWRITE_TAC [MODULE_MOR]);;

let MODULE_MOR_o = prove
  (`MODULE_MOR op i mop1 mop2 h /\ MODULE_MOR op i mop2 mop3 g ==>
    MODULE_MOR op i mop1 mop3 (g o h)`,
   REWRITE_TAC [MODULE_MOR] THEN STRIP_TAC THEN ASM_REWRITE_TAC [o_DEF]);;

(* ------------------------------------------------------------------------- *)
(*  Pull-back modules.                                                       *)
(* ------------------------------------------------------------------------- *)

let PBMOP = new_definition
  `PBMOP op' i' op i h mop f = mop (h o f)`;;

let PB_MODULE = prove
  (`OPERAD_MOR op' i' op i h /\
    MODULE op i mop
    ==> MODULE op' i' (PBMOP op' i' op i h mop)`,
   REWRITE_TAC [OPERAD_MOR; MODULE_DEF; PBMOP] THEN STRIP_TAC THEN
   ASM_REWRITE_TAC [o_DEF; ETA_AX]);;


(* ------------------------------------------------------------------------- *)
(*  Derived Modules.                                                         *)
(* ------------------------------------------------------------------------- *)

let DMOP = new_definition
  `DMOP k op i mop f x = mop (\n. if n < k then i n else
                                  op (\n. i (k + n)) (f (n - k))) x`;;

let DMOP_0 = prove
  (`!op i mop. OPERAD op i ==> DMOP 0 op i mop = mop`,
   REWRITE_TAC [OPERAD_DEF] THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FUN_EQ_THM; DMOP; LT; ADD; SUB_0; ETA_AX]);;

prove
  (`!op i mop. (!k. MODULE op i (DMOP k op i mop))
                   ==> MODULE op i mop`,
   MESON_TAC [MODULE_DEF; DMOP_0]);;


g (`!op (i:num->A) mop k. MODULE op i mop ==>
                          MODULE op i (DMOP k op i mop)`);;
e (REWRITE_TAC [MODULE_DEF; DMOP] THEN REPEAT GEN_TAC THEN SIMP_TAC []);;
e (REWRITE_TAC [OPERAD_DEF] THEN REPEAT STRIP_TAC);;
e (SUBGOAL_THEN `(\n. if n < k then i n else i (k + n - k)) = i:num->A`
     (fun th -> ASM_REWRITE_TAC [th]));;
e (REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC THEN
   COND_CASES_TAC THEN REWRITE_TAC []);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN
   GEN_TAC THEN ASM_REWRITE_TAC []);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (SUBGOAL_THEN `~(k + x' < k)` (fun th -> ASM_REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (AP_TERM_TAC THEN AP_TERM_TAC THEN ASM_ARITH_TAC);;
let DMODULE = top_thm ();;

let DMODULE_MOR = prove
  (`MODULE_MOR op i mop1 mop2 h ==>
   MODULE_MOR op i (DMOP k op i mop1) (DMOP k op i mop2) h`,
   SIMP_TAC [MODULE_MOR; DMODULE; DMOP]);;

let MODULE_MOR_INV = prove
  (`MODULE_MOR op i mop1 mop2 h /\
    (!x:A. g (h x) = x) /\ (!y:B. h (g y) = y) ==>
    MODULE_MOR op i mop2 mop1 g`,
   REWRITE_TAC [MODULE_MOR] THEN ASM_MESON_TAC []);;

let MODULE_ISOM = new_definition
  `MODULE_ISOM op i mop1 mop2 h g <=>
     MODULE_MOR op i mop1 mop2 h /\
     (!x:A. g (h x) = x) /\ (!y:B. h (g y) = y)`;;

let MODULE_ISOM_SYM = prove
  (`!op i mop1 mop2 h g.
      MODULE_ISOM op i mop1 mop2 h g /\
      (!x. g (h x) = x) /\ (!x. h (g x) = x)
      ==> MODULE_ISOM op i mop2 mop1 g h`,
   REPEAT GEN_TAC THEN SIMP_TAC [MODULE_ISOM] THEN STRIP_TAC THEN
   MATCH_MP_TAC MODULE_MOR_INV THEN ASM_REWRITE_TAC []);;

let EXP_OPERAD = new_definition
  `EXP_OPERAD op i h g <=>
     MODULE_ISOM op i op (DMOP (SUC 0) op i op) h g`;;
