(* -*- holl -*- *)

needs "Operad/lc_operad.ml";;
needs "Operad/slc_alt.ml";;

(* Sostituire la vecchia. *)

let SLC_EXP_MAP = new_recursive_definition SLC_RECURSION
  `(!op h g i. SLC_EXP_MAP op h g (REF i) = OPERAD_UNIT op i) /\
   (!op h g x y.
      SLC_EXP_MAP op h g (APP x y) =
        op (\n. if n = 0 then SLC_EXP_MAP op h g y else
                OPERAD_UNIT op (PRE n)) (h (SLC_EXP_MAP op h g x))) /\
   (!op h g x. SLC_EXP_MAP op h g (ABS x) = g (SLC_EXP_MAP op h g x))`;;

g `SUBST f (ABS x) =
   ABS (SUBST (\i. if i = 0 then REF i else SUBST (REF o SUC)
              (f (PRE i))) x)`;;
e (REWRITE_TAC [SUBST; SLC_CONSTR_INJ]);;
e (MATCH_MP_TAC SUBST_FUN_EXTENS);;
e (REWRITE_TAC [SHIFTF; TRIVIAL_ARITH]);;
e (GEN_TAC THEN COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT_EQ_SUBST]);;
e (REWRITE_TAC [TRIVIAL_ARITH; SUB; o_DEF]);;


g `!op (h:A->A) g x k n.
     OPERAD op /\
     (!f x. h (op f x) =
            op (\i. if i = 0 then OPERAD_UNIT op i else
                    OPERAD_SHIFT op 0 (SUC 0) (f (PRE i)))
               (h x)) /\
     (!f x. op f (g x) =
            g (op (\i. if i = 0 then OPERAD_UNIT op i else
                       op (OPERAD_UNIT op o SUC) (f (PRE i)))
                  x))
     ==> SLC_EXP_MAP op h g (SHIFT k n x) =
         op (\i. if i < k then OPERAD_UNIT op i else OPERAD_UNIT op (n + i))
            (SLC_EXP_MAP op h g x)`;;
e (SUBGOAL_THEN `!op (h:A->A) g.
     OPERAD op /\
     (!f x. h (op f x) =
            op (\i. if i = 0 then OPERAD_UNIT op i else
                    OPERAD_SHIFT op 0 (SUC 0) (f (PRE i)))
               (h x)) /\
     (!f x. op f (g x) =
            g (op (\i. if i = 0 then OPERAD_UNIT op i else
                       op (OPERAD_UNIT op o SUC) (f (PRE i)))
                  x))
     ==> !x k n.
           SLC_EXP_MAP op h g (SHIFT k n x) =
           op (\i. if i < k then OPERAD_UNIT op i else OPERAD_UNIT op (n + i))
              (SLC_EXP_MAP op h g x)`
      (fun th -> MESON_TAC [th]));;
e (REPEAT GEN_TAC THEN REWRITE_TAC [OPERAD] THEN STRIP_TAC THEN
   SLC_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_REWRITE_TAC [SLC_EXP_MAP; SHIFT]);;
e (REWRITE_TAC [IF_DISTRIB]);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (ASM_REWRITE_TAC [IF_DISTRIB; OPERAD_SHIFT; TRIVIAL_ARITH]);;
e (AP_TERM_TAC THEN AP_THM_TAC THEN AP_TERM_TAC THEN
   REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (ASM_CASES_TAC `x = 0` THEN ASM_REWRITE_TAC [TRIVIAL_ARITH]);;
e (ASM_REWRITE_TAC [IF_DISTRIB; o_THM]);;
e (AP_TERM_TAC);;
e (ASM_SIMP_TAC [ARITH_RULE `~(x = 0) ==> (PRE x < k <=> x < SUC k)`]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [TRIVIAL_ARITH]);;
e (ASM_SIMP_TAC [ARITH_RULE `~(x = 0) ==> SUC (PRE x) = x`]);;
e (ASM_SIMP_TAC [ARITH_RULE `~(x = 0) ==> SUC (n + PRE x) = n + x`]);;
let SLC_EXP_MAP_SHIFT = top_thm ();;

g `!op (h:A->A) g x f.
     OPERAD op /\
     (!f x. h (op f x) =
            op (\i. if i = 0 then OPERAD_UNIT op i else
                    OPERAD_SHIFT op 0 (SUC 0) (f (PRE i)))
               (h x)) /\
     (!f x. op f (g x) =
            g (op (\i. if i = 0 then OPERAD_UNIT op i else
                       op (OPERAD_UNIT op o SUC) (f (PRE i)))
                  x))
     ==> SLC_EXP_MAP op h g (SUBST f x) =
         op (SLC_EXP_MAP op h g o f) (SLC_EXP_MAP op h g x)`;;
e (SUBGOAL_THEN
   `!op (h:A->A) g.
     OPERAD op /\
     (!f x. h (op f x) =
            op (\i. if i = 0 then OPERAD_UNIT op i else
                    OPERAD_SHIFT op 0 (SUC 0) (f (PRE i)))
               (h x)) /\
     (!f x. op f (g x) =
            g (op (\i. if i = 0 then OPERAD_UNIT op i else
                       op (OPERAD_UNIT op o SUC) (f (PRE i)))
                  x))
     ==> !x f. SLC_EXP_MAP op h g (SUBST f x) =
               op (SLC_EXP_MAP op h g o f) (SLC_EXP_MAP op h g x)`
      (fun th -> MESON_TAC [th]));;
e (REPEAT GEN_TAC THEN REWRITE_TAC [OPERAD] THEN STRIP_TAC THEN
   SUBGOAL_THEN `OPERAD (op:(num->A)->A->A)` ASSUME_TAC THENL
   [ASM_REWRITE_TAC [OPERAD]; ALL_TAC] THEN
   SLC_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_REWRITE_TAC [SLC_EXP_MAP; SUBST; o_THM]);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [OPERAD_SHIFT; o_THM]);;
e (MATCH_MP_TAC OPERAD_RUNIT_IMP);;
e (ASM_REWRITE_TAC [TRIVIAL_ARITH]);;
e (AP_TERM_TAC);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (ASM_REWRITE_TAC [o_THM; SHIFTF; SHIFT; LT]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SLC_EXP_MAP; SHIFT_EQ_SUBST; TRIVIAL_ARITH]);;
e (TRANS_TAC `SLC_EXP_MAP op (h:A->A) g (SHIFT 0 (SUC 0) (f (PRE x)))`);;
e (AP_TERM_TAC THEN REWRITE_TAC [SHIFT_EQ_SUBST; TRIVIAL_ARITH]);;
e (REPEAT AP_TERM_TAC);;
e (ASM_SIMP_TAC [ARITH_RULE `~(x = 0) ==> x - SUC 0 = PRE x`]);;
e (ASM_SIMP_TAC [SLC_EXP_MAP_SHIFT]);;
e (REWRITE_TAC [o_DEF; TRIVIAL_ARITH]);;
let SLC_EXP_MAP_SUBST = top_thm ();;


g `!op (h:A->A) g.
     OPERAD op /\
     (!x. h (g x) = x) /\ (!x. g (h x) = x) /\
     (!f x. h (op f x) =
            op (\i. if i = 0 then OPERAD_UNIT op i else
                    OPERAD_SHIFT op 0 (SUC 0) (f (PRE i)))
               (h x)) /\
     (!f x. op f (g x) =
            g (op (\i. if i = 0 then OPERAD_UNIT op i else
                       op (OPERAD_UNIT op o SUC) (f (PRE i)))
                  x))
     ==>
     (!i. SLC_EXP_MAP op h g (REF i) = OPERAD_UNIT op i) /\
     (!x. SLC_EXP_MAP op h g (APP0 x) = h (SLC_EXP_MAP op h g x)) /\
     (!x. SLC_EXP_MAP op h g (ABS x) = g (SLC_EXP_MAP op h g x)) /\
     (!t x. SLC_EXP_MAP op h g (SUBST t x) =
            op (SLC_EXP_MAP op h g o t) (SLC_EXP_MAP op h g x))`;;
e (REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [APP0; SLC_EXP_MAP]);;
e (ASM_SIMP_TAC [SLC_EXP_MAP_SHIFT; OPERAD_ASSOC]);;
e (MATCH_MP_TAC OPERAD_RUNIT_IMP);;
e (ASM_REWRITE_TAC [TRIVIAL_ARITH]);;
e (GEN_TAC THEN COND_CASES_TAC THEN
   ASM_SIMP_TAC [OPERAD_SHIFT; OPERAD_LUNIT; TRIVIAL_ARITH]);;
e (ASM_SIMP_TAC [ARITH_RULE `~(i = 0) ==> SUC (PRE i) = i`]);;
e (ASM_SIMP_TAC [SLC_EXP_MAP_SUBST]);;
let SLC_EXP_MAP_ALT = top_thm ();;
