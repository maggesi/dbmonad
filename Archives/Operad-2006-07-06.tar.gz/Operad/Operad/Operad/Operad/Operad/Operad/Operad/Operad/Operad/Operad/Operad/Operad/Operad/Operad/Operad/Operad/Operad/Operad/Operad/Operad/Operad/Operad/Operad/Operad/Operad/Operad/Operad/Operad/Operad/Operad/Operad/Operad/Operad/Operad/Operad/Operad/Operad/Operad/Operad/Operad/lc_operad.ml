(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "Operad/operad.ml";;
needs "Operad/lc.ml";;

(* Teorema SUBST con quantificatori *)
(* Cambiare alcuni thm con _PROJ *)

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let SLC_OPERAD = prove
  (`OPERAD SUBST`,
   REWRITE_TAC [OPERAD_DEF; SUBST_ASSOC; o_DEF] THEN
   EXISTS_TAC `REF` THEN REWRITE_TAC [SUBST; SUBST_LUNIT]);;

let SLC_OPERAD_UNIT = prove
  (`OPERAD_UNIT SUBST = REF`,
   MATCH_MP_TAC OPERAD_UNIT_UNIQUE THEN
   REWRITE_TAC [SLC_OPERAD; SUBST; SUBST_LUNIT]);;

let LC_OPERAD = prove
  (`OPERAD LC_SUBST`,
   REWRITE_TAC [OPERAD_DEF; LC_SUBST_ASSOC; o_DEF] THEN
   EXISTS_TAC `LC_REF` THEN
   REWRITE_TAC [LC_SUBST_RUNIT; LC_SUBST_LUNIT]);;

let LC_OPERAD_UNIT = prove
  (`OPERAD_UNIT LC_SUBST = LC_REF`,
   MATCH_MP_TAC OPERAD_UNIT_UNIQUE THEN
   REWRITE_TAC [LC_OPERAD; LC_SUBST_LUNIT; LC_SUBST_RUNIT]);;

let LC_DMOP = prove
  (`!k f x. DMOP k LC_SUBST LC_SUBST (LC_PROJ o f) (LC_PROJ x) =
      LC_PROJ (DMOP k SUBST SUBST f x)`,
   REPEAT GEN_TAC THEN
   REWRITE_TAC [DMOP; SLC_OPERAD_UNIT; LC_OPERAD_UNIT; GSYM LC_SUBST_PROJ] THEN
   MATCH_MP_TAC LC_SUBST_FUN_EXTENS THEN GEN_TAC THEN
   REWRITE_TAC [FUN_EQ_THM] THEN COND_CASES_TAC THEN
   ASM_REWRITE_TAC [GSYM LC_SUBST_PROJ; o_THM; LC_REF] THEN
   MATCH_MP_TAC LC_SUBST_FUN_EXTENS THEN REWRITE_TAC [o_THM]);;

let LC_ABS_MODULE_MOR = prove
  (`MODULE_MOR LC_SUBST (DMOP (SUC 0) LC_SUBST LC_SUBST) LC_SUBST LC_ABS`,
   SIMP_TAC [MODULE_MOR; SELF_MODULE; LC_OPERAD; MODULE_DMOP] THEN
   MATCH_MP_TAC LC_THM_FUN_LIFT THEN GEN_TAC THEN
   MATCH_MP_TAC LC_THM_LIFT THEN GEN_TAC THEN
   REWRITE_TAC [LC_DMOP; LC_ABS; LC_SUBST_PROJ] THEN
   AP_TERM_TAC THEN REWRITE_TAC [SUBST; DMOP; SLC_OPERAD_UNIT] THEN
   AP_TERM_TAC THEN MATCH_MP_TAC SUBST_FUN_EXTENS THEN GEN_TAC THEN
   REWRITE_TAC [FUN_EQ_THM; SHIFTF; SHIFT_EQ_SUBST; LT; SHIFTF_0]);;

let LC_APP0_MODULE_MOR = prove
  (`MODULE_ISOM LC_SUBST LC_SUBST (DMOP (SUC 0) LC_SUBST LC_SUBST)
      LC_APP0 LC_ABS`,
   MESON_TAC [MODULE_ISOM_SYM; LC_APP0_ABS; LC_ABS_APP0;
              MODULE_ISOM; LC_ABS_MODULE_MOR]);;

let LC_EXP = prove
  (`EXP_OPERAD LC_SUBST LC_APP0 LC_ABS`,
   REWRITE_TAC [EXP_OPERAD; LC_APP0_MODULE_MOR]);;

let LCR_EXP_RULES = prove
 (`(!x. LCR (APP0 (ABS x)) x) /\
   (!x. LCR (ABS (APP0 x)) x) /\
   (!x y. LCR x y ==> LCR (APP0 x) (APP0 y)) /\
   (!x y. LCR x y ==> LCR (ABS x) (ABS y)) /\
   (!x y. LCR x y ==> LCR y x) /\
   (!f g x y. (!z. LCR (f z) (g z)) /\ LCR x y
              ==> LCR (SUBST f x) (SUBST g y)) /\
   (!x y z. LCR x y /\ LCR y z ==> LCR x z)`,
   REWRITE_TAC [LCR_RULES; LCR_SUBST; LCR_ABS_APP0; LCR_APP0; LCR_APP0_ABS]);;

let FF = new_recursive_definition SLC_RECURSION
  `(!i. FF (REF i) = REF i) /\
   (!x. FF (ABS x) = ABS (FF x)) /\
   (!x y. FF (APP x y) = SUBST (\n. if n = 0 then FF y else REF (PRE n))
                               (APP0 (FF x)))`;;

let LCR_FF = prove
  (`!x. LCR x (FF x)`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FF; LCR_REFL; LCR_ABS] THEN
   MATCH_MP_TAC LCR_TRANS THEN EXISTS_TAC `APP (FF a0) (FF a1)` THEN
   ASM_SIMP_TAC [LCR_APP; LCR_APP_APP0]);;

let SLC_INDUCT_2 = prove
  (`!P. (!i. P (REF i)) /\
        (!x. P x ==> P (ABS x)) /\
        (!x. P x ==> P (APP0 x)) /\
        (!f x. (!i. P (f i)) /\ P x ==> P (SUBST f x)) /\
        (!x y. P x /\ LCR x y ==> P y)
        ==> (!x. P x)`,
   GEN_TAC THEN STRIP_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_SIMP_TAC [] THEN
   FIRST_X_ASSUM MATCH_MP_TAC THEN
   EXISTS_TAC `SUBST (\n. if n = 0 then a1 else REF (PRE n)) (APP0 a0)` THEN
   CONJ_TAC THENL
   [FIRST_X_ASSUM MATCH_MP_TAC THEN ASM_SIMP_TAC[] THEN
    GEN_TAC THEN COND_CASES_TAC THEN ASM_REWRITE_TAC [];
    MATCH_MP_TAC LCR_SYM THEN ASM_SIMP_TAC [LCR_APP_APP0]]);;

g `!f g.
     (!i. f (REF i) = g (REF i)) /\
     (!x. f x = g x ==> f (ABS x) = g (ABS x)) /\
     (!x. f x = g x ==> f (APP0 x) = g (APP0 x)) /\
     (!h x. (!i. f (h i) = g (h i)) /\ (f x = g x) ==>
            f (SUBST h x) = g (SUBST h x)) /\
     (!x y. f x = g x /\ LCR x y ==> f y = g y)
     ==> f = g`;;
e (REPEAT STRIP_TAC THEN REWRITE_TAC [FUN_EQ_THM]);;
e (MATCH_MP_TAC SLC_INDUCT_2 THEN REPEAT STRIP_TAC THEN ASM_SIMP_TAC []);;
e (ASM_MESON_TAC[]);;
let SLC_RECURSION_2_UNIQUE = top_thm ();;

