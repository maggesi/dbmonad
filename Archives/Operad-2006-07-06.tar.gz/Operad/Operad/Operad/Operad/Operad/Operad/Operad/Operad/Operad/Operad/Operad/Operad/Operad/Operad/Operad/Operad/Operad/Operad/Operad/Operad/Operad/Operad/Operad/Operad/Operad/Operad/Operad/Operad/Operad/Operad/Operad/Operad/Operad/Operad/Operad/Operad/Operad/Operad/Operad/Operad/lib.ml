(* -*- holl -*- *)

needs "Operad/moreset.ml";;
needs "Operad/moretacs.ml";;

let IF_DISTRIB = MESON []
  `!f b x y. (if b then f x else f y) = f (if b then x else y)`;;

let TRIVIAL_ARITH = prove
 (`(!n. 0 + n = n) /\
   (!n. n + 0 = n) /\
   (!n. n - 0 = n) /\
   (!n. ~(n < 0)) /\ 
   (!n. ~(SUC n = 0)) /\
   (!n. 0 < SUC n) /\
   (!m n. SUC m = SUC n <=> m = n) /\
   (!m n. SUC m < SUC n <=> m < n) /\
   (!m n. SUC m - SUC n = m - n) /\
   (!m n. SUC m + n = SUC (m + n)) /\ 
   (!m n. m + SUC n = SUC (m + n)) /\ 
   (!n. PRE (SUC n) = n) /\
   (!n. n <= 0 <=> n = 0) /\
   (!n. n < SUC 0 <=> n = 0)`,
   REWRITE_TAC [NOT_SUC; PRE; LE; LT_0; LT; SUC_INJ;
                ADD; ADD_0; ADD_SUC; SUB_0; SUB_SUC; LT_SUC]);;
