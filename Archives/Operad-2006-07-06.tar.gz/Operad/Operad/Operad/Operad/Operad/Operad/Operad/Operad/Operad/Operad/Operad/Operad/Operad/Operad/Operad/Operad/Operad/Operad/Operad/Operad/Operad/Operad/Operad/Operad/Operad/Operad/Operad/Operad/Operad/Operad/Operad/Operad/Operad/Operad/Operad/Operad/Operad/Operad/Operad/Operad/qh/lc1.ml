(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "/home/maggesi/Trees/HOL/hol_light/Permutation/nummax.ml";;
needs "/home/maggesi/Trees/HOL/hol_light/Permutation/morelist.ml";;
needs "/home/maggesi/Trees/HOL/hol_light/Operad/moreset.ml";;


let ASM_ARITH_TAC =
  POP_ASSUM_LIST (MP_TAC o end_itlist CONJ) THEN ARITH_TAC;;


(* ------------------------------------------------------------------------- *)
(*  Basic defs                                                               *)
(* ------------------------------------------------------------------------- *)

let SLC_INDUCT, SLC_RECURSION = define_type
  "SLC = REF num
       | APP SLC SLC
       | ABS SLC";;

let FV = new_recursive_definition SLC_RECURSION
  `FV (REF n) = {n} /\
   FV (APP x y) = FV x UNION FV y /\
   FV (ABS x) = PREIMAGE SUC (FV x)`;;

let FV' = new_recursive_definition SLC_RECURSION
  `FV' k (REF n) = (if n < k then {} else {n - k}) /\
   FV' k (APP x y) = FV' k x UNION FV' k y /\
   FV' k (ABS x) = FV' (SUC k) x`;;

let SHIFT = new_recursive_definition SLC_RECURSION
  `SHIFT k n (REF i) = REF (if i < k then i else n + i) /\
   SHIFT k n (APP x y) = APP (SHIFT k n x) (SHIFT k n y) /\
   SHIFT k n (ABS x) = ABS (SHIFT (SUC k) n x)`;;

let BUMP = new_recursive_definition SLC_RECURSION
  `BUMP k (REF i) = REF (if i < k then i else SUC i) /\
   BUMP k (APP x y) = APP (BUMP k x) (BUMP k y) /\
   BUMP k (ABS x) = ABS (BUMP (SUC k) x)`;;

let SUBST = new_recursive_definition SLC_RECURSION
  `SUBST k f (REF i) = (if i < k then REF i else f (i - k)) /\
   SUBST k f (APP x y) = APP (SUBST k f x) (SUBST k f y) /\
   SUBST k f (ABS x) = ABS (SUBST (SUC k) (BUMP 0 o f) x)`;;


(* ------------------------------------------------------------------------- *)
(*  FV, FV'                                                                  *)
(* ------------------------------------------------------------------------- *)

g `!x k. FV' k x = PREIMAGE ((+) k) (FV x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT CONJ_TAC THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV; FV'; PREIMAGE_UNION; PREIMAGE_SING]);;
e (COND_CASES_TAC THEN
   REWRITE_TAC [IN_SING; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM] THEN
   POP_ASSUM MP_TAC THEN ARITH_TAC);;
e (FIRST_X_ASSUM (fun th -> REWRITE_TAC [GSYM PREIMAGE_o; th]) THEN
   AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_DEF; ADD]);;
let FV'_FV = top_thm ();;

let FV_FV' = prove
  (`!x. FV x = FV' 0 x`,
   GEN_TAC THEN REWRITE_TAC [FV'_FV; PREIMAGE; ADD] THEN SET_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  SHIFT                                                                    *)
(* ------------------------------------------------------------------------- *)

let SHIFT_0 = prove
  (`!x k. SHIFT k 0 x = x`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; ADD] THEN COND_CASES_TAC
   THEN REWRITE_TAC []);;

g `!x h k n m. h <= k ==> SHIFT h n (SHIFT k m x) = SHIFT (k + n) m (SHIFT h n x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (SUBST1_TAC (ARITH_RULE `SUC (k + n) = SUC k + n`));;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_REWRITE_TAC [LE_SUC]);;
let LE_SHIFT_COMM = top_thm ();;

g `!x h k n m. n + h <= k ==> SHIFT k m (SHIFT h n x) =
                              SHIFT h n (SHIFT (k - n) m x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN 
   REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (SUBGOAL_THEN `SUC (k - n) = SUC k - n` SUBST1_TAC);;
e (ASM_ARITH_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_ARITH_TAC);;
let SHIFT_COMM2 = top_thm ();;


g `!n m x h k. k <= h /\ h <= k + m
               ==> SHIFT h n (SHIFT k m x) = SHIFT k (m + n) x`;;
e (GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_ARITH_TAC);;
let SHIFT_SHIFT = top_thm ();;

(* Caso particolare del precedente. *)
let SHIFT_SHIFT_1 = prove
  (`!n m x k. SHIFT k n (SHIFT k m x) = SHIFT k (m + n) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SHIFT] THEN
   AP_TERM_TAC THEN ARITH_TAC);;

(* ENUNCIATO COMPLICATO *)
(*
g `!n x k. FV' k (SHIFT k n x) = IMAGE ((+) n) (FV' k x)`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV'; SHIFT; IMAGE_UNION]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [IMAGE_EMPTY; IMAGE_SING]);;
e (SUBGOAL_THEN `~(n + a < k)` (fun th -> REWRITE_TAC [th; SING_INJ]) THEN
   ASM_ARITH_TAC);;
let FV'_SHIFT_OLD = top_thm ();;
*)

g `!n x k. FV' (n + k) (SHIFT k n x) = FV' k x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FV'; SHIFT]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [] THEN
   COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (n + k) = n + SUC k`]);;
let FV'_SHIFT = top_thm ();;


(* ------------------------------------------------------------------------- *)
(*  BUMP                                                                     *)
(* ------------------------------------------------------------------------- *)

let BUMP_SHIFT = prove
  (`!x k. BUMP k x = SHIFT k (SUC 0) x`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [BUMP; SHIFT; ADD]);;

(* Non abbastanza gengerale *)
(*
g `!x k. FV' (SUC k) (BUMP k x) = FV' k x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FV'; BUMP]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [] THEN
   COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;
let FV'_BUMP = top_thm ();;
*)

g `!x k h. h <= k ==> FV' (SUC k) (BUMP h x) = FV' k x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FV'; BUMP]);;
e (ASM_CASES_TAC `a < h` THEN ASM_REWRITE_TAC [LT_SUC; SUB_SUC]);;
e (REPEAT COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC [LE_SUC]);;
let FV'_BUMP = top_thm ();;

g `!x k. FV' (SUC k) (BUMP 0 x) = FV' k x`;;
e (GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC FV'_BUMP);;
e (REWRITE_TAC [LE_0]);;
let FV'_BUMP_0 = top_thm ();;

let BUMP_OF_SHIFT = prove
  (`!x n h k. k <= h /\ h <= k + n
             ==> BUMP h (SHIFT k n x) = SHIFT k (SUC n) x`,
   ASM_SIMP_TAC [BUMP_SHIFT; SHIFT_SHIFT; ADD_SUC; ADD_0]);;

(* Meno generale. *)
(*
let BUMP_o_SHIFT = prove
  (`!k n. BUMP k o SHIFT k n = SHIFT k (SUC n)`,
   REWRITE_TAC [FUN_EQ_THM; o_DEF; BUMP_SHIFT; SHIFT_SHIFT; ADD]);;
*)




(* ------------------------------------------------------------------------- *)
(*  SUBST                                                                    *)
(* ------------------------------------------------------------------------- *)

g `!x f g k. (!n. n IN FV' k x ==> f n = g n) ==> SUBST k f x = SUBST k g x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REWRITE_TAC [FV'; SUBST]);;
e (REPEAT CONJ_TAC THEN REPEAT GEN_TAC);;
e (COND_CASES_TAC THEN REWRITE_TAC [IN_SING] THEN MESON_TAC []);;
e (REWRITE_TAC [IN_UNION] THEN MESON_TAC []);;
e (REPEAT STRIP_TAC);;
e (AP_TERM_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (REWRITE_TAC [o_DEF]);;
e (ASM_MESON_TAC []);;
let SUBST_FUN_EQ = top_thm ();;

g `!x f k. FV' k (SUBST k f x) = {n | ?m. m IN FV' k x /\ n IN FV' k (f m)}`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REWRITE_TAC [SUBST; FV']);;
e (REPEAT CONJ_TAC THEN REPEAT GEN_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [FV'] THEN SET_TAC []);;
e (SET_TAC []);;
e (DISCH_TAC);;
e (REPEAT GEN_TAC THEN ASM_REWRITE_TAC [o_DEF; FV'_BUMP_0]);;
let FV'_SUBST = top_thm ();;



g `!x k. SUBST k (SHIFT 0 k o REF) x = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SUBST]);;
e (REWRITE_TAC [o_DEF; SHIFT; LT]);;
e (COND_CASES_TAC THEN AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (SUBGOAL_THEN `BUMP 0 o SHIFT 0 k = SHIFT 0 (SUC k)`
     (fun th -> ASM_REWRITE_TAC [o_ASSOC; th]));;
e (REWRITE_TAC [FUN_EQ_THM; o_DEF; BUMP_SHIFT; SHIFT_SHIFT_1; ADD_SUC; ADD_0]);;
let SUBST_SHIFT_0 = top_thm ();;

g `!x k. SUBST 0 REF x = x`;;
e (SUBGOAL_THEN `REF = SHIFT 0 0 o REF` SUBST1_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; o_DEF; SHIFT_0]);;
e (REWRITE_TAC [SUBST_SHIFT_0]);;
let SUBST_REF_UNIT_L = top_thm ();;

g `!x f n h k. h <= k ==> SHIFT k n (SUBST h f x) = SUBST h (SHIFT k n o f) x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [SUBST; SHIFT]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT; o_DEF]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC [o_ASSOC]);;
e (SUBGOAL_THEN `SUC h <= SUC k` ASSUME_TAC);;
e (ASM_REWRITE_TAC [LE_SUC]);;
e (ASM_SIMP_TAC [o_ASSOC]);;
e (REPEAT (AP_TERM_TAC ORELSE AP_THM_TAC));;
e (REWRITE_TAC [FUN_EQ_THM; o_DEF]);;
e (GEN_TAC);;
e (REWRITE_TAC [BUMP_SHIFT; ADD_SUC; ADD_0;
                MATCH_MP LE_SHIFT_COMM (ARITH_RULE `0 <= k`)]);;
let SHIFT_SUBST = top_thm ();;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `!x f h k n. h <= k ==>
               SHIFT h n (SUBST k f x) = SUBST (k + n) f (SHIFT h n x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [SHIFT; SUBST]);;
e (ASM_CASES_TAC `a < h`);;
e (SUBGOAL_THEN `a < k /\ a < k + n` (fun th -> ASM_REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [SHIFT]);;
e (ASM_CASES_TAC `a < k`);;
e (SUBGOAL_THEN `n + a < k + n` (fun th -> ASM_REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [SHIFT]);;
e (SUBGOAL_THEN `~(n + a < k + n)` (fun th -> ASM_REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;



e (ASM_REWRITE_TAC [SHIFT]);;





g `!x f g. SUBST 0 g (SUBST 0 f x) = SUBST 0 (\n. SUBST 0 g (f n)) x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST]);;
e (REWRITE_TAC [LT; SUB_0]);;
e (AP_TERM_TAC);;
e (SUBGOAL_THEN `BUMP 0 o (\n. SUBST 0 g (f n)) = \n:num. BUMP 0 (SUBST 0 g (f n))`
     (fun th -> REWRITE_TAC [th]));;
e (REWRITE_TAC [FUN_EQ_THM; o_DEF]);;
e (SUBGOAL_THEN `BUMP 0 = SHIFT 0 (SUC 0)` SUBST1_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; BUMP_SHIFT]);;
