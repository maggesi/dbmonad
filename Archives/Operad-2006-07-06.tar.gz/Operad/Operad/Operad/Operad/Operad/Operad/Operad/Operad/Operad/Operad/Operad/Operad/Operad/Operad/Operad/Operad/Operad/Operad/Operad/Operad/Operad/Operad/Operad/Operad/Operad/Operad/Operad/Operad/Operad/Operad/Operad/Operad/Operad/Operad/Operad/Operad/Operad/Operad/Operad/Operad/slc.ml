(* -*- holl -*- *)

(* ========================================================================= *)
(*  Syntactic Lambda Calculus "a la" de Bruijn.                              *)
(*  Here syntactic means: "terms are not identified by beta-eta relation".   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "Operad/lib.ml";;

(* ------------------------------------------------------------------------- *)
(*  Type for lambda terms using de Bruijn notation.                          *)
(* ------------------------------------------------------------------------- *)

let dbterm_INDUCT, dbterm_RECURSION = define_type
  "dbterm = REF num
       | APP dbterm dbterm
       | ABS dbterm";;

(* ------------------------------------------------------------------------- *)
(*  Basic operations on lambda terms.                                        *)
(* ------------------------------------------------------------------------- *)

let SHIFT = new_recursive_definition dbterm_RECURSION
  `(!k n i. SHIFT k n (REF i) = REF (if i < k then i else n + i)) /\
   (!k n x y. SHIFT k n (APP x y) = APP (SHIFT k n x) (SHIFT k n y)) /\
   (!k n x. SHIFT k n (ABS x) = ABS (SHIFT (SUC k) n x))`;;

let SHIFTF = new_definition
  `!f k i. SHIFTF k f i = if i < k then REF i else SHIFT 0 k (f (i - k))`;;

let SUBST = new_recursive_definition dbterm_RECURSION
  `(!f i. SUBST f (REF i) = f i) /\
   (!f x y. SUBST f (APP x y) = APP (SUBST f x) (SUBST f y)) /\
   (!f x. SUBST f (ABS x) = ABS (SUBST (SHIFTF (SUC 0) f) x))`;;

let APP0 = new_definition
  `APP0 x = APP (SHIFT 0 (SUC 0) x) (REF 0)`;;

let DBTERM_INDUCT_TAC =
  MATCH_MP_TAC dbterm_INDUCT THEN CONJ_TAC THENL
  [GEN_TAC; CONJ_TAC THEN GEN_TAC THENL
   [GEN_TAC THEN DISCH_THEN (CONJUNCTS_THEN ASSUME_TAC); DISCH_TAC]];;

let dbterm_CASES = MESON [dbterm_INDUCT]
  `!P. (!a. P (REF a)) /\ (!a0 a1. P (APP a0 a1)) /\ (!a. P (ABS a))
            ==> (!x. P x)`;;

let DBTERM_CASES_TAC =
  MATCH_MP_TAC dbterm_INDUCT THEN CONJ_TAC THENL
  [GEN_TAC; CONJ_TAC THEN GEN_TAC THENL
   [GEN_TAC; ALL_TAC]];;

(* ------------------------------------------------------------------------- *)
(*  Trivial lemmas                                                           *)
(* ------------------------------------------------------------------------- *)

let IF_REF = prove
  (`!b x y. (if b then REF x else REF y) = REF (if b then x else y)`,
   REWRITE_TAC [IF_DISTRIB]);;

let DBTERM_CONSTR_INJ = injectivity "dbterm";;

let DBTERM_CONSTR_DIST = distinctness "dbterm";;

let REF_INJ = MESON [DBTERM_CONSTR_INJ]
  `!x y. REF x = REF y <=> x = y`;;

(* ------------------------------------------------------------------------- *)
(*  SHIFT                                                                    *)
(* ------------------------------------------------------------------------- *)

let SHIFT_0 = prove
  (`!x k. SHIFT k 0 x = x`,
   MATCH_MP_TAC dbterm_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; ADD] THEN COND_CASES_TAC
   THEN REWRITE_TAC []);;

let SHIFT_INJ = prove
  (`!x y n k. SHIFT k n x = SHIFT k n y <=> x = y`,
   DBTERM_INDUCT_TAC THEN DBTERM_CASES_TAC THEN
   ASM_REWRITE_TAC [SHIFT; DBTERM_CONSTR_INJ; DBTERM_CONSTR_DIST] THEN
   ARITH_TAC);;

let LE_SHIFT_COMM = prove
  (`!x h k n m. h <= k ==> SHIFT h n (SHIFT k m x) =
                          SHIFT (k + n) m (SHIFT h n x)`,
   DBTERM_INDUCT_TAC THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [SHIFT; DBTERM_CONSTR_INJ; LE_SUC; ADD] THEN ASM_ARITH_TAC);;

let LE_SHIFT_COMM_0 = prove
  (`!x k n m. SHIFT 0 n (SHIFT k m x) =
              SHIFT (k + n) m (SHIFT 0 n x)`,
   SIMP_TAC [SPECL [`x:dbterm`; `0`] LE_SHIFT_COMM; LE_0]);;

(* Symmetric of LE_SHIFT_COMM *)
let GE_SHIFT_COMM = prove
  (`!x h k n m. m + k <= h ==> SHIFT h n (SHIFT k m x) =
                               SHIFT k m (SHIFT (h - m) n x)`,
   REPEAT STRIP_TAC THEN
   SUBGOAL_THEN `k <= h - m /\ h - m + m = h`
    (fun th -> SIMP_TAC [LE_SHIFT_COMM; th]) THEN
   ASM_ARITH_TAC);;

let SHIFT_SHIFT = prove
  (`!x n m h k. k <= h /\ h <= k + m
               ==> SHIFT h n (SHIFT k m x) = SHIFT k (m + n) x`,
   DBTERM_INDUCT_TAC THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [SHIFT; DBTERM_CONSTR_INJ; LE_SUC; ADD] THEN
   ASM_ARITH_TAC);;

let SHIFT_SHIFT_0 = prove
  (`(!k n m x. SHIFT k n (SHIFT k m x) = SHIFT k (m + n) x) /\
    (!k n x. SHIFT k n (SHIFT 0 k x) = SHIFT 0 (k + n) x)`,
   REPEAT STRIP_TAC THEN MATCH_MP_TAC SHIFT_SHIFT THEN
   REWRITE_TAC [LE_0; LE_REFL; ADD] THEN ARITH_TAC);;

let SHIFTF_0 = prove
  (`!f. SHIFTF 0 f = f`,
   REWRITE_TAC [FUN_EQ_THM; SHIFTF; SHIFT_0; LT; SUB_0]);;

let SHIFTF_REF = prove
  (`SHIFTF k REF = REF`,
   REWRITE_TAC [FUN_EQ_THM; SHIFTF; SHIFT; IF_REF; REF_INJ; LT] THEN
   ARITH_TAC);;

let SHIFTF_SHIFTF = prove
  (`!f h k. SHIFTF h (SHIFTF k f) = SHIFTF (h + k) f`,
   REPEAT GEN_TAC THEN
   REWRITE_TAC [SHIFTF; FUN_EQ_THM; ISPEC `SHIFT 0 h` (GSYM IF_DISTRIB);
                SHIFT; SHIFT_SHIFT_0; LT] THEN
   GEN_TAC THEN COND_CASES_TAC THENL
   [ASM_SIMP_TAC [ARITH_RULE `x < h ==> x < h + k`];
    ASM_SIMP_TAC [ARITH_RULE `~(x < h) ==> (x - h < k <=> x < h + k)`] THEN
   COND_CASES_TAC THEN REWRITE_TAC [REF_INJ; ADD_AC] THEN
   REPEAT AP_TERM_TAC THEN ASM_ARITH_TAC]);;

(* ------------------------------------------------------------------------- *)
(*  SUBST                                                                    *)
(* ------------------------------------------------------------------------- *)

let SUBST_FUN_EXTENS = prove
  (`!f g x. (!n. f n = g n) ==> SUBST f x = SUBST g x`,
   REPEAT STRIP_TAC THEN AP_THM_TAC THEN AP_TERM_TAC THEN
   ASM_REWRITE_TAC [FUN_EQ_THM]);;

let SUBST_LUNIT = prove
  (`!x n. SUBST REF x = x`,
   MATCH_MP_TAC dbterm_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF_REF]);;

let SUBST_LUNIT_IMP = prove
  (`!f x. (!i. f i = REF i) ==> SUBST f x = x`,
   REPEAT GEN_TAC THEN REWRITE_TAC [GSYM FUN_EQ_THM] THEN
   DISCH_TAC THEN ASM_SIMP_TAC [SUBST_LUNIT]);;

let SHIFT_EQ_SUBST = time prove
  (`!x k n. SHIFT k n x = SUBST (\i. if i < k then REF i else REF (n + i)) x`,
   DBTERM_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; IF_REF; DBTERM_CONSTR_INJ] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN
   REWRITE_TAC [SHIFTF; SHIFT; LT; IF_REF; REF_INJ] THEN
   NUM_CASES_TAC THEN REWRITE_TAC [TRIVIAL_ARITH; IF_DISTRIB; SUC_INJ] THEN
   ARITH_TAC);;

let SHIFT_SUBST = prove
  (`!x f k n. SHIFT k n (SUBST f x) = SUBST (SHIFT k n o f) x`,
   MATCH_MP_TAC dbterm_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; DBTERM_CONSTR_INJ; o_THM] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN GEN_TAC THEN
   REWRITE_TAC [o_THM; SHIFTF; TRIVIAL_ARITH] THEN COND_CASES_TAC THEN
   ASM_REWRITE_TAC [SHIFT; LE_SHIFT_COMM_0; TRIVIAL_ARITH]);;

let SUBST_SHIFT = prove
  (`!x f k n. SUBST f (SHIFT k n x) =
      SUBST (\i. if i < k then f i else f (n + i)) x`,
   DBTERM_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; IF_DISTRIB; DBTERM_CONSTR_INJ] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN
   NUM_CASES_TAC THEN ASM_REWRITE_TAC [SHIFTF; TRIVIAL_ARITH] THEN
   ASM_CASES_TAC `n' < k` THEN ASM_REWRITE_TAC [TRIVIAL_ARITH]);;

let SHIFT_SUBST_COMM = prove
  (`!x f n. SHIFT 0 n (SUBST f x) = SUBST (SHIFTF n f) (SHIFT 0 n x)`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SHIFT_SUBST; SUBST_SHIFT; LT] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN GEN_TAC THEN
   REWRITE_TAC [o_THM; SHIFTF] THEN
   REWRITE_TAC [ARITH_RULE `~(n + n' < n) /\ (n + n') - n = n'`]);;

g `!x f g. SUBST f (SUBST g x) = SUBST (SUBST f o g) x`;;
e (DBTERM_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_REWRITE_TAC [SUBST; DBTERM_CONSTR_INJ; o_THM]);;
e (MATCH_MP_TAC SUBST_FUN_EXTENS THEN GEN_TAC);;
e (REWRITE_TAC [o_THM; SHIFTF]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [] THEN
   ASM_REWRITE_TAC [SHIFT_SUBST_COMM; SUBST; SHIFTF]);;
let SUBST_ASSOC = top_thm ();;

let SHIFT_LEFT_INV = prove
  (`!k n x. SUBST (SHIFTF k (\i. REF (i - n))) (SHIFT k n x) = x`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SUBST_SHIFT] THEN
   MATCH_MP_TAC SUBST_LUNIT_IMP THEN
   REWRITE_TAC [SHIFTF; SHIFT; LT; IF_REF; REF_INJ] THEN ARITH_TAC);;

let SHIFT_0_LEFT_INV = MESON [SHIFT_LEFT_INV; SHIFTF_0]
  `!n x. SUBST (\i. REF (i - n)) (SHIFT 0 n x) = x`;;


(* ------------------------------------------------------------------------- *)
(*  APP0                                                                     *)
(* ------------------------------------------------------------------------- *)

let SUBST_APP0 = prove
  (`!x f. SUBST f (APP0 x) = APP (SUBST (f o SUC) x) (f 0)`,
   REWRITE_TAC [APP0; SUBST; o_DEF; SUBST_SHIFT; TRIVIAL_ARITH]);;

let APP0_SUBST = prove
  (`!x f. APP0 (SUBST f x) = SUBST (SHIFTF (SUC 0) f) (APP0 x)`,
   REWRITE_TAC [APP0; SUBST; SHIFTF; SHIFT_SUBST_COMM; TRIVIAL_ARITH]);;

let APP_EQ_APP0 = prove
  (`!x y. APP x y = SUBST (\n. if n = 0 then y else REF (PRE n)) (APP0 x)`,
   REWRITE_TAC [SUBST_APP0; o_DEF; TRIVIAL_ARITH; ETA_AX; SUBST_LUNIT]);;

let dbterm_INDUCT_ALT = prove
  (`!P. (!i. P (REF i)) /\
       (!x. P x ==> P (APP0 x)) /\
       (!x. P x ==> P (ABS x)) /\
       (!f x. (!i. P (f i)) /\ P x ==> P (SUBST f x))
       ==> (!x. P x)`,
   GEN_TAC THEN STRIP_TAC THEN MATCH_MP_TAC dbterm_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_SIMP_TAC [APP_EQ_APP0] THEN
   FIRST_X_ASSUM MATCH_MP_TAC THEN ASM_SIMP_TAC [] THEN
   GEN_TAC THEN COND_CASES_TAC THEN ASM_REWRITE_TAC[]);;
