(* -*- holl -*- *)

needs "Examples/rstc.ml";;
needs "Operad/slc.ml";;

(* ------------------------------------------------------------------------- *)
(*  DBTERM_BETA                                                              *)
(* ------------------------------------------------------------------------- *)

let DBTERM_BETA_RULES, DBTERM_BETA_INDUCT, DBTERM_BETA_CASES =
  new_inductive_definition
  `!x y. DBTERM_BETA (APP (ABS x) y)
           (SUBST (\n. if n = 0 then y else REF (PRE n)) x)`;;

let DBTERM_BETA_THM = prove
  (`!x y z. DBTERM_BETA (APP (ABS x) y) z <=>
            z = SUBST (\n. if n = 0 then y else REF (PRE n)) x`,
   REPEAT GEN_TAC THEN EQ_TAC THEN SIMP_TAC [DBTERM_BETA_RULES] THEN
   ONCE_REWRITE_TAC [DBTERM_BETA_CASES] THEN
   REWRITE_TAC [DBTERM_CONSTR_INJ] THEN STRIP_TAC THEN ASM_REWRITE_TAC []);;

(* ------------------------------------------------------------------------- *)
(*  DBTERM_ETA                                                               *)
(* ------------------------------------------------------------------------- *)

let DBTERM_ETA_RULES, DBTERM_ETA_INDUCT, DBTERM_ETA_CASES =
  new_inductive_definition
  `!x. DBTERM_ETA (ABS (APP (SHIFT 0 (SUC 0) x) (REF 0))) x`;;

let DBTERM_ETA_CASES_ALT = prove
  (`!x y. DBTERM_ETA x y <=> x = ABS (APP0 y)`,
   REWRITE_TAC [DBTERM_ETA_CASES; APP0]);;

let SHIFT_ETA = prove
  (`!x y k n. DBTERM_ETA x y ==> DBTERM_ETA (SHIFT k n x) (SHIFT k n y)`,
   SUBGOAL_THEN `!x y. DBTERM_ETA x y
                       ==> (!n k. DBTERM_ETA (SHIFT k n x) (SHIFT k n y))`
     (fun th -> MESON_TAC [th]) THEN
   MATCH_MP_TAC DBTERM_ETA_INDUCT THEN REPEAT GEN_TAC THEN
   REWRITE_TAC [DBTERM_ETA_CASES; SHIFT; TRIVIAL_ARITH; LE_SHIFT_COMM_0]);;

let DBTERM_REL_RULES, DBTERM_REL_INDUCT, DBTERM_REL_CASES =
  new_inductive_definition
  `(!x y. R x y ==> DBTERM_REL R x y) /\
   (!x y. DBTERM_REL R x y ==> DBTERM_REL R (ABS x) (ABS y)) /\
   (!x y z. DBTERM_REL R x y ==> DBTERM_REL R (APP x z) (APP y z)) /\
   (!x y z. DBTERM_REL R x y ==> DBTERM_REL R (APP z x) (APP z y))`;;

let DBTERM_EQV = new_definition
  `!R. DBTERM_EQV R = RSTC (DBTERM_REL R)`;;

let DBTERM_EQV_INC = prove
  (`!R x y. R x y ==> DBTERM_EQV R x y`,
   SIMP_TAC [DBTERM_EQV; RSTC_INC; DBTERM_REL_RULES]);;

let DBTERM_EQV_REFL = prove
  (`!R x. DBTERM_EQV R x x`,
   REWRITE_TAC [DBTERM_EQV; RSTC_REFL]);;

let DBTERM_EQV_REFL_IMP = MESON [DBTERM_EQV_REFL]
  `!R x y. x = y ==> DBTERM_EQV R x y`;;

let DBTERM_EQV_SYM = prove
  (`!R x y. DBTERM_EQV R x y ==> DBTERM_EQV R y x`,
   REWRITE_TAC [DBTERM_EQV; RSTC_SYM]);;

let DBTERM_EQV_TRANS = prove
  (`!R x y z. DBTERM_EQV R x y /\ DBTERM_EQV R y z ==> DBTERM_EQV R x z`,
   REWRITE_TAC [DBTERM_EQV; RSTC_TRANS]);;

let DBTERM_EQV_ABS = prove
  (`!R x y. DBTERM_EQV R x y ==> DBTERM_EQV R (ABS x) (ABS y)`,
   GEN_TAC THEN REWRITE_TAC [DBTERM_EQV] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL_RULES]);;

let DBTERM_EQV_APP_L = prove
  (`!R z x y. DBTERM_EQV R x y ==> DBTERM_EQV R (APP x z) (APP y z)`,
   GEN_TAC THEN GEN_TAC THEN REWRITE_TAC [DBTERM_EQV] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN MESON_TAC [RSTC_RULES; DBTERM_REL_RULES]);;

let DBTERM_EQV_APP_R = prove
  (`!R z x y. DBTERM_EQV R x y ==> DBTERM_EQV R (APP z x) (APP z y)`,
   GEN_TAC THEN GEN_TAC THEN REWRITE_TAC [DBTERM_EQV] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN MESON_TAC [RSTC_RULES; DBTERM_REL_RULES]);;

let DBTERM_EQV_APP =
  MESON [DBTERM_EQV_TRANS; DBTERM_EQV_APP_L; DBTERM_EQV_APP_R]
  `!R x1 x2 y1 y1. DBTERM_EQV R x1 y1 /\ DBTERM_EQV R x2 y2
                   ==> DBTERM_EQV R (APP x1 x2) (APP y1 y2)`;;

let DBTERM_EQV_RULES = MESON [DBTERM_EQV_INC; DBTERM_EQV_APP; DBTERM_EQV_ABS;
                           DBTERM_EQV_REFL; DBTERM_EQV_SYM; DBTERM_EQV_TRANS]
  `!R. (!x y. R x y ==> DBTERM_EQV R x y) /\
       (!x y. DBTERM_EQV R x y ==> DBTERM_EQV R (ABS x) (ABS y)) /\
       (!x1 x2 y1 y1. DBTERM_EQV R x1 y1 /\ DBTERM_EQV R x2 y2
                      ==> DBTERM_EQV R (APP x1 x2) (APP y1 y2)) /\
       (!x. DBTERM_EQV R x x) /\
       (!x y. DBTERM_EQV R x y ==> DBTERM_EQV R y x) /\
       (!x y z. DBTERM_EQV R x y /\ DBTERM_EQV R y z ==> DBTERM_EQV R x z)`;;

let DBTERM_EQV_CASES = prove
  (`!a0 a1.
       DBTERM_EQV R a0 a1 <=>
       R a0 a1 \/
       (?x1 y1 x2 y2.
            a0 = APP x1 x2 /\ a1 = APP y1 y2 /\
            DBTERM_EQV R x1 y1 /\ DBTERM_EQV R x2 y2) \/
       (?x y. a0 = ABS x /\ a1 = ABS y /\ DBTERM_EQV R x y) \/
       DBTERM_EQV R a1 a0 \/
       (?y. DBTERM_EQV R a0 y /\ DBTERM_EQV R y a1)`,
   REPEAT GEN_TAC THEN EQ_TAC THENL
   [REWRITE_TAC [DBTERM_EQV] THEN MESON_TAC [RSTC_CASES; RSTC_RULES];
    MESON_TAC [DBTERM_EQV_RULES]]);;

let DBTERM_EQV_INDUCT = prove
  (`!RR R. (!x y. R x y ==> RR x y) /\
          (!x1 y1 x2 y2.
             RR x1 y1 /\ RR x2 y2 ==> RR (APP x1 x2) (APP y1 y2)) /\
          (!x y. RR x y ==> RR (ABS x) (ABS y)) /\
          (!x. RR x x) /\
          (!x y. RR x y ==> RR y x) /\
          (!x y z. RR x y /\ RR y z ==> RR x z)
          ==> (!a0 a1. DBTERM_EQV R a0 a1 ==> RR a0 a1)`,
   GEN_TAC THEN GEN_TAC THEN STRIP_TAC THEN REWRITE_TAC [DBTERM_EQV] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN CONJ_TAC THEN
   TRY (MATCH_MP_TAC DBTERM_REL_INDUCT) THEN ASM_MESON_TAC []);;

(* ------------------------------------------------------------------------- *)
(*  LC relation                                                              *)
(* ------------------------------------------------------------------------- *)

let LCR = new_definition
  `LCR = DBTERM_EQV (\x y. DBTERM_BETA x y \/ DBTERM_ETA x y)`;;

let LCR_BETA = prove
  (`!x y. DBTERM_BETA x y ==> LCR x y`,
   SIMP_TAC [LCR; DBTERM_EQV_INC]);;

let LCR_ETA = prove
  (`!x y. DBTERM_ETA x y ==> LCR x y`,
   SIMP_TAC [LCR; DBTERM_EQV_INC]);;

let LCR_ABS = prove
  (`!x y. LCR x y ==> LCR (ABS x) (ABS y)`,
   SIMP_TAC [LCR; DBTERM_EQV_ABS]);;

let LCR_APP = prove
  (`!x1 y1 x2 y2. LCR x1 y1 /\ LCR x2 y2 ==> LCR (APP x1 x2) (APP y1 y2)`,
   SIMP_TAC [LCR; DBTERM_EQV_APP]);;

let LCR_REFL = prove
  (`!x. LCR x x`,
   REWRITE_TAC [LCR; DBTERM_EQV_REFL]);;

let LCR_SYM = prove
  (`!x y. LCR x y ==> LCR y x`,
   REWRITE_TAC [LCR; DBTERM_EQV_SYM]);;

let LCR_TRANS = prove
  (`!x y z. LCR x y /\ LCR y z ==> LCR x z`,
   REWRITE_TAC [LCR; DBTERM_EQV_TRANS]);;

let LCR_RULES = prove
  (`(!x y. DBTERM_BETA x y ==> LCR x y) /\
    (!x y. DBTERM_ETA x y ==> LCR x y) /\
    (!x1 y1 x2 y2. LCR x1 y1 /\ LCR x2 y2 ==> LCR (APP x1 x2) (APP y1 y2)) /\
    (!x y. LCR x y ==> LCR (ABS x) (ABS y)) /\
    (!x. LCR x x) /\
    (!x y. LCR x y ==> LCR y x) /\
    (!x y z. LCR x y /\ LCR y z ==> LCR x z)`,
  REWRITE_TAC [LCR_REFL; LCR_SYM; LCR_BETA; LCR_ETA; LCR_ABS; LCR_APP] THEN
  MESON_TAC [LCR_TRANS]);;

let LCR_INDUCT = prove
  (`!LCR'. (!x y. DBTERM_BETA x y ==> LCR' x y) /\
          (!x y. DBTERM_ETA x y ==> LCR' x y) /\
          (!x1 y1 x2 y2.
             LCR' x1 y1 /\ LCR' x2 y2 ==> LCR' (APP x1 x2) (APP y1 y2)) /\
          (!x y. LCR' x y ==> LCR' (ABS x) (ABS y)) /\
          (!x y. LCR' x y ==> LCR' y x) /\
          (!x y z. LCR' x y /\ LCR' y z ==> LCR' x z)
          ==> (!a0 a1. LCR a0 a1 ==> LCR' a0 a1)`,
   GEN_TAC THEN STRIP_TAC THEN REWRITE_TAC [LCR; DBTERM_EQV] THEN
   SUBGOAL_THEN `!x:dbterm. LCR' x x` ASSUME_TAC THENL
   [ASM_MESON_TAC [DBTERM_ETA_RULES];
    MATCH_MP_TAC RSTC_INDUCT] THEN ASM_REWRITE_TAC [] THEN
    MATCH_MP_TAC DBTERM_REL_INDUCT THEN ASM_MESON_TAC []);;

let LCR_CASES = prove
  (`!a0 a1.
       LCR a0 a1 <=>
       DBTERM_BETA a0 a1 \/
       DBTERM_ETA a0 a1 \/
       (?x1 y1 x2 y2.
            a0 = APP x1 x2 /\ a1 = APP y1 y2 /\ LCR x1 y1 /\ LCR x2 y2) \/
       (?x y. a0 = ABS x /\ a1 = ABS y /\ LCR x y) \/
       LCR a1 a0 \/
       (?y. LCR a0 y /\ LCR y a1)`,
   REPEAT GEN_TAC THEN EQ_TAC THENL
   [REWRITE_TAC [LCR] THEN MESON_TAC [DBTERM_EQV_CASES];
    ASM_MESON_TAC [LCR_RULES]]);;

let SHIFT_BETA = prove
  (`!x y k n. DBTERM_BETA x y ==> DBTERM_BETA (SHIFT k n x) (SHIFT k n y)`,
   REPEAT GEN_TAC THEN
   DISCH_THEN (STRIP_ASSUME_TAC o REWRITE_RULE [DBTERM_BETA_CASES]) THEN
   POP_ASSUM_LIST (MAP_EVERY SUBST1_TAC) THEN
   REWRITE_TAC [SHIFT; DBTERM_BETA_THM; SHIFT_SUBST; SUBST_SHIFT] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN NUM_CASES_TAC THEN
   REWRITE_TAC [TRIVIAL_ARITH; o_THM; SHIFT; IF_REF]);;

let LCR_SHIFT_IMP = prove
  (`!x y k n. LCR x y ==> LCR (SHIFT k n x) (SHIFT k n y)`,
   SUBGOAL_THEN `!x y. LCR x y ==> !k n. LCR (SHIFT k n x) (SHIFT k n y)`
    (fun th -> SIMP_TAC [th]) THEN
   MATCH_MP_TAC LCR_INDUCT THEN REWRITE_TAC [SHIFT] THEN
   MESON_TAC [LCR_RULES; SHIFT_BETA; SHIFT_ETA]);;

let LCR_SHIFTF = prove
  (`!f g k n. (!n. LCR (f n) (g n)) ==> LCR (SHIFTF k f n) (SHIFTF k g n)`,
   REWRITE_TAC [SHIFTF] THEN ASM_MESON_TAC [LCR_SHIFT_IMP; LCR_REFL]);;

let LCR_SUBST_FUN = prove
  (`!x f g. (!i. LCR (f i) (g i)) ==> LCR (SUBST f x) (SUBST g x)`,
   DBTERM_INDUCT_TAC THEN ASM_SIMP_TAC [SUBST; LCR_APP] THEN
   ASM_MESON_TAC [LCR_ABS; LCR_SHIFTF]);;

(* ------------------------------------------------------------ *)
(* ------------------------------------------------------------ *)

let SUBST_BETA_TERM = prove
  (`!x y f. DBTERM_BETA x y ==> DBTERM_BETA (SUBST f x) (SUBST f y)`,
   REPEAT GEN_TAC THEN
   DISCH_THEN (STRIP_ASSUME_TAC o REWRITE_RULE [DBTERM_BETA_CASES]) THEN
   POP_ASSUM_LIST (MAP_EVERY SUBST1_TAC) THEN
   REWRITE_TAC [SUBST; DBTERM_BETA_THM; SUBST_ASSOC] THEN
   MATCH_MP_TAC SUBST_FUN_EXTENS THEN NUM_CASES_TAC THEN
   REWRITE_TAC [SUBST; o_THM; SHIFTF; TRIVIAL_ARITH] THEN
   REWRITE_TAC [SUBST_SHIFT; TRIVIAL_ARITH] THEN
   REWRITE_TAC [ETA_AX; SUBST_LUNIT]);;

let SUBST_ETA_TERM = prove
  (`!x y f. DBTERM_ETA x y ==> DBTERM_ETA (SUBST f x) (SUBST f y)`,
   REWRITE_TAC [DBTERM_ETA_CASES_ALT] THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; APP0_SUBST]);;

let LCR_SUBST_TERM = prove
  (`!x y f. LCR x y ==> LCR (SUBST f x) (SUBST f y)`,
   SUBGOAL_THEN `!x y. LCR x y ==> !f. LCR (SUBST f x) (SUBST f y)`
     (fun th -> MESON_TAC [th]) THEN
   MATCH_MP_TAC LCR_INDUCT THEN REWRITE_TAC [SUBST] THEN
   ASM_MESON_TAC [LCR_RULES; SUBST_BETA_TERM; SUBST_ETA_TERM]);;

let LCR_SUBST = prove
  (`!f g x y. (!n. LCR (f n) (g n)) /\ LCR x y
              ==> LCR (SUBST f x) (SUBST g y)`,
   MESON_TAC [LCR_SUBST_TERM; LCR_SUBST_FUN; LCR_TRANS]);;

let LCR_SHIFT = prove
  (`!k n x y. LCR (SHIFT k n x) (SHIFT k n y) <=> LCR x y`,
   MESON_TAC [LCR_SHIFT_IMP; SHIFT_LEFT_INV; LCR_SUBST_TERM]);;

let LCR_APP0 = prove
  (`!x y. LCR x y ==> LCR (APP0 x) (APP0 y)`,
   REPEAT STRIP_TAC THEN REWRITE_TAC [APP0] THEN
   ASM_SIMP_TAC [LCR_RULES; LCR_SHIFT; LCR_REFL]);;

(* ------------------------------------------------------------------------- *)
(*  A nice consequence of eta.                                               *)
(* ------------------------------------------------------------------------- *)

let LCR_ABS_APP0 = prove
  (`!x. LCR (ABS (APP0 x)) x`,
   SIMP_TAC [APP0; LCR_ETA; DBTERM_ETA_RULES]);;

(* ------------------------------------------------------------------------- *)
(*  A nice consequence of beta.                                              *)
(* ------------------------------------------------------------------------- *)

let LCR_APP0_ABS = prove
  (`!x. LCR (APP0 (ABS x)) x`,
   GEN_TAC THEN REWRITE_TAC [APP0; SHIFT] THEN MATCH_MP_TAC LCR_BETA THEN
   REWRITE_TAC [DBTERM_BETA_THM; SHIFT_EQ_SUBST; SUBST_ASSOC] THEN
   MATCH_MP_TAC (GSYM SUBST_LUNIT_IMP) THEN NUM_CASES_TAC THEN
   REWRITE_TAC [SUBST; IF_REF; o_THM; TRIVIAL_ARITH]);;

(* ------------------------------------------------------------------------- *)
(*  How to express APP in terms of APP0 (modulo LCR).                        *)
(* ------------------------------------------------------------------------- *)

let LCR_APP_APP0 = prove
  (`!x y. LCR (APP x y)
      (SUBST (\n. if n = 0 then y else REF (PRE n)) (APP0 x))`,
   REPEAT GEN_TAC THEN MATCH_MP_TAC LCR_TRANS THEN
   EXISTS_TAC `APP (ABS (APP (SHIFT 0 (SUC 0) x) (REF 0))) y` THEN
   REWRITE_TAC [APP0] THEN 
   MESON_TAC [LCR_RULES; DBTERM_ETA_RULES; DBTERM_BETA_RULES]);;

let APP0_ABS_REL_RULES, APP0_ABS_REL_INDUCT, APP0_ABS_REL_CASES =
   new_inductive_definition
    `!x. APP0_ABS_REL (APP0 (ABS x)) x`;;

let ABS_APP0_REL_RULES, ABS_APP0_REL_INDUCT, ABS_APP0_REL_CASES =
   new_inductive_definition
    `!x. ABS_APP0_REL (ABS (APP0 x)) x`;;

g `!x y. DBTERM_EQV (\x y. APP0_ABS_REL x y \/ ABS_APP0_REL x y) x y
         ==> LCR x y`;;
e (MATCH_MP_TAC DBTERM_EQV_INDUCT THEN
   REWRITE_TAC [APP0_ABS_REL_CASES; ABS_APP0_REL_CASES] THEN
   MESON_TAC [LCR_RULES; LCR_ABS_APP0; LCR_APP0_ABS]);;
