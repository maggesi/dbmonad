(* -*- holl -*- *)

(* ========================================================================= *)
(*  Lambda Calculus.                                                         *)
(*  Terms of Syntactic Lambda Calculus defined in "slc.ml" are here          *)
(*  identified using beta-eta relation.                                      *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "Operad/slc.ml";;

(* ------------------------------------------------------------------------- *)
(*  LC lambda calculus                                                       *)
(* ------------------------------------------------------------------------- *)

let LC_TYBIJ =
  define_quotient_type "LC" ("MK_LC","DEST_LC") `LCR`;;

let lc_lift_function =
  lift_function (snd LC_TYBIJ) (LCR_REFL,LCR_TRANS);;

let LC_PROJ = new_definition
  `LC_PROJ n = MK_LC (LCR n)`;;

let LC_PROJ_LCR = prove
  (`!x y. LC_PROJ x = LC_PROJ y <=> LCR x y`,
   REPEAT GEN_TAC THEN TRANS_TAC `LCR x = LCR y` THENL
   [REWRITE_TAC [LC_PROJ] THEN MESON_TAC [fst LC_TYBIJ; snd LC_TYBIJ];
    MESON_TAC [FUN_EQ_THM; LCR_REFL; LCR_TRANS; LCR_SYM]]);;

let MK_LC_SURJ = prove
  (`!a. ?p. MK_LC p = a /\ (?x. p = LCR x)`,
   MESON_TAC [fst LC_TYBIJ; snd LC_TYBIJ]);;

let LC_PROJ_SURJ = prove
  (`!y. ?x. LC_PROJ x = y`,
   REWRITE_TAC [LC_PROJ] THEN
   MESON_TAC [fst LC_TYBIJ; snd LC_TYBIJ]);;

let LC_LIFT = new_definition
  `LC_LIFT y = (@x. LC_PROJ x = y)`;;

let LC_PROJ_LIFT = prove
  (`!y. LC_PROJ (LC_LIFT y) = y`,
   REWRITE_TAC [LC_LIFT] THEN MESON_TAC [SELECT_AX; LC_PROJ_SURJ]);;

let LC_LIFT_PROJ = prove
  (`!x. LCR (LC_LIFT (LC_PROJ x)) x`,
   REWRITE_TAC [LC_LIFT; LC_PROJ_LCR] THEN
   MESON_TAC [SELECT_AX; LCR_REFL]);;

let LC_ABS, LC_ABS_TH = lc_lift_function "LC_ABS" LCR_ABS;;

let LC_APP, LC_APP_TH = lc_lift_function "LC_APP" LCR_APP;;

let LC_REF = new_definition `LC_REF i = MK_LC (LCR (REF i))`;;

let LC_SHIFT, LC_SHIFT_TH = lc_lift_function "LC_SHIFT"
  (prove (`!x y k j n m. LCR x y /\ k = j /\ n = m
                         ==> LCR (SHIFT k n x) (SHIFT j m y)`,
   MESON_TAC [LCR_SHIFT]));;

let LC_SUBST = new_definition
  `LC_SUBST f x =
     LC_PROJ (SUBST (LC_LIFT o f) (LC_LIFT x))`;;

let LC_SUBST_H = prove
  (`!f x. LC_SUBST (LC_PROJ o f) (LC_PROJ x) = LC_PROJ (SUBST f x)`,
   REPEAT GEN_TAC THEN REWRITE_TAC [LC_SUBST; o_DEF; LC_PROJ_LCR] THEN
   MESON_TAC [LCR_SUBST; LC_LIFT_PROJ]);;

let LC_APP1, LC_APP1_TH = lc_lift_function "LC_APP1" APP1_LCR;;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let LC_ABS_FACT =  prove
  (`!x. LC_ABS (LC_PROJ x) = LC_PROJ (ABS x)`,
   REWRITE_TAC [LC_PROJ; LC_ABS_TH]);;

let LC_APP_FACT =  prove
  (`!x y. LC_APP (LC_PROJ x)  (LC_PROJ y) = LC_PROJ (APP x y)`,
   REWRITE_TAC [LC_PROJ; LC_APP_TH]);;

let LC_REF_FACT =  prove
  (`!i. LC_REF i = LC_PROJ (REF i)`,
   REWRITE_TAC [LC_PROJ; LC_REF]);;

let LC_SHIFT_FACT = prove
  (`!x k n. LC_SHIFT (LC_PROJ x) k n = LC_PROJ (SHIFT k n x)`,
   REWRITE_TAC [LC_PROJ; LC_SHIFT_TH]);;

let LC_APP1_FACT =  prove
  (`!x. LC_APP1 (LC_PROJ x) = LC_PROJ (APP1 x)`,
   REWRITE_TAC [LC_PROJ; LC_APP1_TH]);;

g `!x. LC_SUBST LC_REF x = x`;;
e (GEN_TAC THEN CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ));;
e (SUBGOAL_THEN `LC_REF = LC_PROJ o REF` SUBST1_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; LC_REF; o_DEF; LC_PROJ]);;
e (REWRITE_TAC [LC_SUBST_H; SUBST_REF_UNIT_L]);;
let LC_SUBST_REF_UNIT_L = top_thm ();;

g `!f i. LC_SUBST f (LC_REF i) = f i`;;
e (REPEAT GEN_TAC);;
e (TRANS_TAC `LC_SUBST (LC_PROJ o (LC_LIFT o f)) (LC_PROJ (REF i))`);;
e (REWRITE_TAC [o_DEF; LC_PROJ_LIFT; ETA_AX]);;
e (REWRITE_TAC [LC_REF; LC_PROJ]);;
e (REWRITE_TAC [LC_SUBST_H; SUBST; o_DEF; LC_PROJ_LIFT]);;
let LC_SUBST_REF_UNIT_R = top_thm ();;

g `!f g x. LC_SUBST f (LC_SUBST g x) = LC_SUBST (LC_SUBST f o g) x`;;
e (REPEAT GEN_TAC);;
e (TRANS_TAC `LC_SUBST (LC_PROJ o (LC_LIFT o f))
                (LC_SUBST (LC_PROJ o (LC_LIFT o  g)) x)`);;
e (REWRITE_TAC [o_DEF; LC_PROJ_LIFT; ETA_AX]);;
e (CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ));;
e (REWRITE_TAC [LC_SUBST_H; SUBST_SUBST]);;
e (SUBGOAL_THEN `LC_SUBST f = LC_PROJ o (SUBST (LC_LIFT o f)) o LC_LIFT`
     SUBST1_TAC);;
e (REWRITE_TAC [FUN_EQ_THM] THEN GEN_TAC);;
e (CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ));;
e (TRANS_TAC `LC_SUBST (LC_PROJ o (LC_LIFT o f)) (LC_PROJ x')`);;
e (REWRITE_TAC [o_DEF; LC_PROJ_LIFT; ETA_AX]);;
e (REWRITE_TAC [LC_SUBST_H; o_DEF; LC_PROJ_LCR]);;
e (MATCH_MP_TAC LCR_SUBST);;
e (REWRITE_TAC [GSYM LC_PROJ_LCR; LC_PROJ_LIFT]);;
e (REWRITE_TAC [GSYM o_ASSOC; LC_SUBST_H]);;
let LC_SUBST_ASSOC = top_thm ();;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let LC_PROJ_o_LC_LIFT = prove
  (`!x. LC_PROJ o LC_LIFT = (\x. x)`,
   REWRITE_TAC [o_DEF; LC_PROJ_LIFT]);;

g `!f. LC_SUBST f = LC_PROJ o (SUBST (LC_LIFT o f)) o LC_LIFT`;;
e (GEN_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_THM] THEN GEN_TAC);;
e (TRANS_TAC `LC_SUBST (LC_PROJ o (LC_LIFT o f)) (LC_PROJ (LC_LIFT x))`);;
e (REWRITE_TAC [LC_PROJ_LIFT; o_DEF; ETA_AX]);;
e (REWRITE_TAC [LC_SUBST_H]);;
let LC_SUBST_SLC = top_thm ();;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let LC_ABS_LC_APP1 = prove
  (`!x. LC_ABS (LC_APP1 x) = x`,
   GEN_TAC THEN
   CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ) THEN
   REWRITE_TAC [LC_APP1_FACT; LC_ABS_FACT; LC_PROJ_LCR; ABS_APP1_LCR]);;

let LC_APP1_LC_ABS = prove
  (`!x. LC_APP1 (LC_ABS x) = x`,
   GEN_TAC THEN
   CHOOSE_THEN (SUBST1_TAC o GSYM) (SPEC `x:LC` LC_PROJ_SURJ) THEN
   REWRITE_TAC [LC_APP1_FACT; LC_ABS_FACT; LC_PROJ_LCR; APP1_ABS_LCR]);;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let LC_LIFT_PROJ_RW = prove
  (`!x y. LCR (LC_LIFT (LC_PROJ x)) y <=> LCR x y`,
   MESON_TAC [LC_LIFT_PROJ; LCR_TRANS; LCR_REFL; LCR_SYM]);;
