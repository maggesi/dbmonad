(* -*- holl -*- *)

needs "showtime.ml";;
needs "Operad/dbterm.ml";;
needs "Operad/slc_alt.ml";;
needs "Operad/lc_exp.ml";;

needs "Operad/lc.ml";;
needs "Operad/lc_operad.ml";;
needs "Operad/subst1.ml";;
needs "Operad/fv.ml";;
