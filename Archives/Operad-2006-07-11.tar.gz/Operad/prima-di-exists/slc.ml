(* -*- holl -*- *)

(* ========================================================================= *)
(*  Syntactic Lambda Calculus "a la" de Bruijn.                              *)
(*  Here syntactic means: "terms are not identified by beta-eta relation".   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

needs "Operad/moreset.ml";;
needs "Operad/moretacs.ml";;


(* ------------------------------------------------------------------------- *)
(*  Basic defs                                                               *)
(* ------------------------------------------------------------------------- *)

let SLC_INDUCT, SLC_RECURSION = define_type
  "SLC = REF num
       | APP SLC SLC
       | ABS SLC";;

let REF_INJ = prove
  (`!x y. REF x = REF y <=> x = y`,
   REWRITE_TAC [injectivity "SLC"]);;

let ABS_INJ = prove
  (`!x y. ABS x = ABS y <=> x = y`,
   REWRITE_TAC [injectivity "SLC"]);;

let APP_INJ = prove
  (`!x1 x2 y1 y2. APP x1 x2 = APP y1 y2 <=> x1 = y1 /\ x2 = y2`,
   REWRITE_TAC [injectivity "SLC"]);;

let NOT_REF_APP =
  (`!i x y. ~(REF i = APP x y)`,
    REWRITE_TAC [distinctness "SLC"]);;

let NOT_REF_ABS =
  (`!i x. ~(REF i = ABS x)`,
    REWRITE_TAC [distinctness "SLC"]);;

let NOT_APP_ABS =
  (`!x y z. ~(APP x y = ABS z)`,
    REWRITE_TAC [distinctness "SLC"]);;

let FV = new_recursive_definition SLC_RECURSION
  `FV (REF n) = {n} /\
   FV (APP x y) = FV x UNION FV y /\
   FV (ABS x) = PREIMAGE SUC (FV x)`;;

let FV' = new_recursive_definition SLC_RECURSION
  `FV' k (REF n) = (if n < k then {} else {n - k}) /\
   FV' k (APP x y) = FV' k x UNION FV' k y /\
   FV' k (ABS x) = FV' (SUC k) x`;;

let SHIFT = new_recursive_definition SLC_RECURSION
  `SHIFT k n (REF i) = REF (if i < k then i else n + i) /\
   SHIFT k n (APP x y) = APP (SHIFT k n x) (SHIFT k n y) /\
   SHIFT k n (ABS x) = ABS (SHIFT (SUC k) n x)`;;

let SHIFTF = new_definition
  `SHIFTF k f i = if i < k then REF i else SHIFT 0 k (f (i - k))`;;

let SUBST = new_recursive_definition SLC_RECURSION
  `SUBST f (REF i) = f i /\
   SUBST f (APP x y) = APP (SUBST f x) (SUBST f y) /\
   SUBST f (ABS x) = ABS (SUBST (SHIFTF (SUC 0) f) x)`;;


(* ------------------------------------------------------------------------- *)
(*  FV, FV'                                                                  *)
(* ------------------------------------------------------------------------- *)

g `!x k. FV' k x = PREIMAGE ((+) k) (FV x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT CONJ_TAC THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV; FV'; PREIMAGE_UNION; PREIMAGE_SING]);;
e (COND_CASES_TAC THEN
   REWRITE_TAC [IN_SING; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM] THEN
   POP_ASSUM MP_TAC THEN ARITH_TAC);;
e (FIRST_X_ASSUM (fun th -> REWRITE_TAC [GSYM PREIMAGE_o; th]) THEN
   AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_DEF; ADD]);;
let FV'_FV = top_thm ();;

let FV_FV' = prove
  (`!x. FV x = FV' 0 x`,
   GEN_TAC THEN REWRITE_TAC [FV'_FV; PREIMAGE; ADD] THEN SET_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  SHIFT                                                                    *)
(* ------------------------------------------------------------------------- *)

let SHIFT_0 = prove
  (`!x k. SHIFT k 0 x = x`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; ADD] THEN COND_CASES_TAC
   THEN REWRITE_TAC []);;

g `!x h k n m. h <= k ==> SHIFT h n (SHIFT k m x) =
                          SHIFT (k + n) m (SHIFT h n x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (SUBST1_TAC (ARITH_RULE `SUC (k + n) = SUC k + n`));;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_REWRITE_TAC [LE_SUC]);;
let LE_SHIFT_COMM = top_thm ();;

(* Caso particolare del teorema precedente. *)
let LE_SHIFT_COMM_0 = prove
  (`!x h k n m. SHIFT 0 n (SHIFT k m x) =
                SHIFT (k + n) m (SHIFT 0 n x)`,
   SIMP_TAC [SPECL [`x:SLC`; `0`] LE_SHIFT_COMM; LE_0]);;

(* Symmetric of LE_SHIFT_COMM *)
let GT_SHIFT_COMM = prove
  (`!x h k n m. m + k <= h ==> SHIFT h n (SHIFT k m x) =
                               SHIFT k m (SHIFT (h - m) n x)`,
   REPEAT STRIP_TAC THEN
   SUBGOAL_THEN `k <= h - m /\ h - m + m = h`
    (fun th -> SIMP_TAC [LE_SHIFT_COMM; th]) THEN
   ASM_ARITH_TAC);;

g `!x n m h k. k <= h /\ h <= k + m
               ==> SHIFT h n (SHIFT k m x) = SHIFT k (m + n) x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (ASM_SIMP_TAC []);;
e (AP_TERM_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (ASM_ARITH_TAC);;
let SHIFT_SHIFT = top_thm ();;

(* Casi particolari del teorema precedente. *)
let SHIFT_SHIFT_0 = prove
  (`SHIFT k n (SHIFT k m x) = SHIFT k (m + n) x /\
     SHIFT k n (SHIFT 0 k x) = SHIFT 0 (k + n) x`,
   CONJ_TAC THEN MATCH_MP_TAC SHIFT_SHIFT THEN
   REWRITE_TAC [LE_0; LE_REFL; ADD] THEN ARITH_TAC);;

(*
let SHIFT_SHIFT_1 = prove
  (`!n m x k. SHIFT k n (SHIFT k m x) = SHIFT k (m + n) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SHIFT] THEN
   AP_TERM_TAC THEN ARITH_TAC);;

let SHIFT_SHIFT_3 = prove
  (`!n x k. SHIFT k n (SHIFT 0 k x) = SHIFT 0 (k + n) x`,
   MESON_TAC [SHIFT_SHIFT; LE_REFL; ADD; LE_0]);;
*)

g `!n x k. FV' (n + k) (SHIFT k n x) = FV' k x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [FV'; SHIFT]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [] THEN
   COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (n + k) = n + SUC k`]);;
let FV'_SHIFT = top_thm ();;

g `!n x k. FV' k (SHIFT 0 k x) = FV' 0 x`;;
e (REPEAT GEN_TAC THEN MATCH_MP_TAC EQ_TRANS);;
e (EXISTS_TAC `FV' (k + 0) (SHIFT 0 k x)`);;
e (CONJ_TAC THENL [REWRITE_TAC [ADD_0]; REWRITE_TAC [FV'_SHIFT]]);;
let FV'_SHIFT_0 = top_thm ();;

g `!f h k. SHIFTF h (SHIFTF k f) = SHIFTF (h + k) f`;;
e (REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF; FUN_EQ_THM]);;
e (GEN_TAC THEN ASM_CASES_TAC `x < h` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `x < h + k` (fun th -> REWRITE_TAC [th]) THEN ASM_ARITH_TAC);;
e (ASM_CASES_TAC `x < h + k` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `x - h < k` (fun th -> REWRITE_TAC [th; SHIFT])
   THEN TRY AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(x - h < k)` (fun th -> REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [SHIFT_SHIFT_0]);;
e (REWRITE_TAC [ADD_AC]);;
e (AP_TERM_TAC THEN AP_TERM_TAC THEN ASM_ARITH_TAC);;
let SHIFTF_SHIFTF = top_thm ();;

g `!n x k. FV' k (SHIFT k n x) = IMAGE (\i. n + i) (FV' k x)`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [FV'; SHIFT; IMAGE_UNION]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [IMAGE_EMPTY]);;
e (COND_CASES_TAC THEN REWRITE_TAC [IMAGE_SING; SING_INJ] THEN
   ASM_ARITH_TAC);;
let FV'_SHIFT_IMAGE = top_thm ();;

let FV_SHIFT_0 = prove
  (`!n x. FV (SHIFT 0 n x) = IMAGE (\i. n + i) (FV x)`,
   REWRITE_TAC [FV_FV'; FV'_SHIFT_IMAGE]);;

let FV_SHIFTF = prove
  (`!f k i. FV (SHIFTF k f i) =
           if i < k then {i} else IMAGE (\i. k + i) (FV (f (i - k)))`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF] THEN COND_CASES_TAC THEN
   REWRITE_TAC [FV; FV_SHIFT_0]);;

let SHIFTF_0 = prove
  (`!f. SHIFTF 0 f = f`,
   REWRITE_TAC [FUN_EQ_THM; SHIFTF; SHIFT_0; LT; SUB_0]);;


(* ------------------------------------------------------------------------- *)
(*  SUBST                                                                    *)
(* ------------------------------------------------------------------------- *)

g `!x f. FV (SUBST f x) = {n | ?m. m IN FV x /\ n IN FV (f m)}`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; FV] THEN REPEAT GEN_TAC);;
e (SET_TAC []);;
e (SET_TAC []);;
e (REWRITE_TAC [FV_SHIFTF; ADD; ETA_AX; IN_PREIMAGE; SUB]);;
e (REWRITE_TAC [ARITH_RULE `m < SUC 0 <=> m = 0`]);;
e (REWRITE_TAC [EXTENSION; IN_PREIMAGE; IN_ELIM_THM]);;
e (GEN_TAC THEN EQ_TAC THEN STRIP_TAC);;
e (EXISTS_TAC `PRE m`);;
e (X_NUM_CASES_TAC `m:num` THEN
   RULE_ASSUM_TAC (REWRITE_RULE [IN_SING; NOT_SUC; IN_IMAGE;
                                 PRE; ADD; SUC_INJ]));;
e (ASM_MESON_TAC []);;
e (ASM_REWRITE_TAC [PRE]);;
e (SET_TAC []);;
e (EXISTS_TAC `SUC m` THEN ASM_REWRITE_TAC [NOT_SUC]);;
e (REWRITE_TAC [IN_IMAGE; ADD; SUC_INJ; PRE]);;
e (SET_TAC []);;
let FV_SUBST = top_thm ();;

g `!x n. SUBST (SHIFTF n REF) x = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF_SHIFTF; ADD]);;
e (REWRITE_TAC [SHIFTF]);;
e (COND_CASES_TAC THEN REWRITE_TAC [SHIFT]);;
e (AP_TERM_TAC THEN ASM_ARITH_TAC);;
let SUBST_REF_UNIT_L_XREF = top_thm ();;

g `!x n. SUBST REF x = x`;;
let th = SUBST_REF_UNIT_L_XREF in
let th = SPECL [`x:SLC`; `0`] th in
let th = REWRITE_RULE [SHIFTF_0] th in
e (REWRITE_TAC [th]);;
let SUBST_REF_UNIT_L = top_thm ();;

g `!x f h k. SUBST (SHIFTF (h + k) f) (SHIFT h k x) =
             SHIFT h k (SUBST (SHIFTF h f) x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFT; SHIFTF_SHIFTF; ADD]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFTF]);;
e (SUBGOAL_THEN `a < h + k` (fun th -> ASM_REWRITE_TAC [th; SHIFT]));;
e (ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(k + a < h + k)` (fun th -> ASM_REWRITE_TAC [th; SHIFT]));;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [SHIFT_SHIFT_0]);;
e (REPEAT AP_TERM_TAC THEN ASM_ARITH_TAC);;
e (AP_TERM_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (h + k) = SUC h + k`]);;
let SHIFT_SUBST_LEMMA1 = top_thm ();;

let SHIFT_SUBST_LEMMA2 = prove
  (`!x f k. SUBST (SHIFTF k f) (SHIFT 0 k x) = SHIFT 0 k (SUBST f x)`,
   MESON_TAC [ADD; SHIFTF_0; SHIFT_SUBST_LEMMA1]);;

let SHIFTF_SUBST = prove
  (`!f g k i. SUBST (SHIFTF k f) (SHIFTF k g i) =
              SHIFTF k (SUBST f o g) i`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF] THEN COND_CASES_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF; o_DEF; SHIFT_SUBST_LEMMA2]);;

let SUBST_SUBST_LEMMA = prove
  (`!f g x k. SUBST (SHIFTF k f) (SUBST (SHIFTF k g) x) =
              SUBST (SHIFTF k (SUBST f o g)) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST; SHIFTF_SHIFTF; ADD; o_DEF; SHIFTF_SUBST]);;

let SUBST_SUBST = prove
  (`!f g x. SUBST f (SUBST g x) = SUBST (SUBST f o g) x`,
   GEN_TAC THEN GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [SUBST; o_DEF; SUBST_SUBST_LEMMA]);;

g `!x f g k. (!n. (k + n) IN FV x ==> f n = g n)
             ==> SUBST (SHIFTF k f) x = SUBST (SHIFTF k g) x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN
   REWRITE_TAC [FV; SUBST; ADD; IN_SING; IN_UNION; IN_PREIMAGE; SHIFTF] THEN
   REPEAT STRIP_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [] THEN AP_TERM_TAC THEN
   FIRST_X_ASSUM MATCH_MP_TAC THEN ASM_ARITH_TAC);;
e (ASM_MESON_TAC []);;
e (REWRITE_TAC [SHIFTF_SHIFTF; ADD] THEN ASM_MESON_TAC [ADD]);;
let SUBST_SHIFTF = top_thm ();;

g `!x f g. (!n. n IN FV x ==> f n = g n) ==> SUBST f x = SUBST g x`;;
let th = SUBST_SHIFTF in
let th = SPECL [`x:SLC`; `f:num->SLC`;  `g:num->SLC`; `0`] th in
let th = REWRITE_RULE [ADD; SHIFTF_0] th in
e (MESON_TAC [th]);;
let FV_SUBST_EQ_IMP = top_thm ();;


(* ------------------------------------------------------------------------- *)
(*  SUBST1                                                                   *)
(* ------------------------------------------------------------------------- *)

let SUBST1 = new_recursive_definition SLC_RECURSION
  `SUBST1 k y (REF i) =
     (if i = k then y else REF (if i < k then i else PRE i)) /\
   SUBST1 k y (APP x1 x2) = APP (SUBST1 k y x1) (SUBST1 k y x2) /\
   SUBST1 k y (ABS x) = ABS (SUBST1 (SUC k) (SHIFT k (SUC 0) y) x)`;;

g `!x y k. SUBST1 k (SHIFT 0 k y) x =
   SUBST (SHIFTF k (\n. if n = 0 then y else REF (PRE n))) x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST1; SUBST]);;
e (ASM_CASES_TAC `a:num = k` THEN
   ASM_REWRITE_TAC [SHIFTF; SUB_REFL; LT_REFL]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `~(a - k = 0)`
    (fun th -> REWRITE_TAC [th; SHIFT; LT; REF_INJ]));;
e (ASM_ARITH_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [SHIFT_SHIFT_0; ADD; ADD_0; ADD_SUC; SHIFTF_SHIFTF]);;
let SUBST1_SUBST = top_thm ();;

let SUBST1_SUBST_0 = prove
  (`!x y. SUBST1 0 y x = SUBST (\n. if n = 0 then y else REF (PRE n)) x`,
   let th = SPECL [`x:SLC`; `y:SLC`; `0`] SUBST1_SUBST in
   let th = REWRITE_RULE [SHIFT_0; SHIFTF_0] th in
   REWRITE_TAC [th]);;

g `!x y k j. SUBST1 j (SHIFT (j + k) i y) (SHIFT (j + SUC k) i x) =
             SHIFT (j + k) i (SUBST1 j y x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST1; ABS_INJ]);;
e (ASM_CASES_TAC `a < j + SUC k` THEN ASM_CASES_TAC `a:num = j` THEN
   ASM_REWRITE_TAC [LT_REFL; SHIFT; REF_INJ]);;
e (ASM_ARITH_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_CASES_TAC `a < j` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `F` (fun th -> MESON_TAC [th]) THEN ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(i + a = j)` (fun th -> REWRITE_TAC [th; REF_INJ]) THEN
   ASM_ARITH_TAC);;
e (REWRITE_TAC [ARITH_RULE `SUC (j + k) = SUC j + k`]);;
e (FIRST_X_ASSUM (fun th -> REWRITE_TAC [GSYM th]));;
e (AP_THM_TAC);;
e (AP_TERM_TAC);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC j + k = (j + k) + SUC 0`]);;
e (MATCH_MP_TAC LE_SHIFT_COMM);;
e (ARITH_TAC);;
let SHIFT_SUBST1 = top_thm ();;


(*
let th = SPECL [`x:SLC`; `y:SLC`; `k:num`; `0`] SHIFT_SUBST1 in
REWRITE_RULE [ADD; SUBST1_SUBST_0] th;;
*)
(*
val it : thm =
  |- SUBST (\n. if n = 0 then SHIFT k i y else REF (PRE n))
     (SHIFT (SUC k) i x) =
     SHIFT k i (SUBST (\n. if n = 0 then y else REF (PRE n)) x)
*)

(* ------------------------------------------------------------------------- *)
(*  SLC_BETA                                                                 *)
(* ------------------------------------------------------------------------- *)

let SLC_BETA_RULES, SLC_BETA_INDUCT, SLC_BETA_CASES = new_inductive_definition
  `!x y. SLC_BETA (APP (ABS x) y)
          (SUBST (\n. if n = 0 then y else REF (PRE n)) x)`;;

let SLC_BETA_RW = prove
  (`!x y z. SLC_BETA (APP (ABS x) y) z <=>
            z = SUBST (\n. if n = 0 then y else REF (PRE n)) x`,
   REPEAT GEN_TAC THEN EQ_TAC THEN SIMP_TAC [SLC_BETA_RULES] THEN
   ONCE_REWRITE_TAC [SLC_BETA_CASES] THEN REWRITE_TAC [APP_INJ; ABS_INJ] THEN
   STRIP_TAC THEN ASM_REWRITE_TAC []);;


(* ------------------------------------------------------------------------- *)
(*  SLC_ETA                                                                  *)
(* ------------------------------------------------------------------------- *)

let SLC_ETA_RULES, SLC_ETA_INDUCT, SLC_ETA_CASES = new_inductive_definition
  `!x. SLC_ETA (ABS (APP (SHIFT 0 (SUC 0) x) (REF 0))) x`;;

g `!x y k n. SLC_ETA x y ==> SLC_ETA (SHIFT k n x) (SHIFT k n y)`;;
e (SUBGOAL_THEN `!x y . SLC_ETA x y
                        ==> (!n k. SLC_ETA (SHIFT k n x) (SHIFT k n y))`
     (fun th -> MESON_TAC [th]));;
e (MATCH_MP_TAC SLC_ETA_INDUCT THEN REPEAT GEN_TAC THEN
   ONCE_REWRITE_TAC [SLC_ETA_CASES]);;
e (REWRITE_TAC [SHIFT; ABS_INJ; APP_INJ; REF_INJ; LT_0]);;
e (REWRITE_TAC [LE_SHIFT_COMM_0; ADD_SUC; ADD_0]);;
let SHIFT_ETA = top_thm ();;


(* ------------------------------------------------------------------------- *)
(*  LC relation                                                              *)
(* ------------------------------------------------------------------------- *)

let LCR_RULES, LCR_INDUCT, LCR_CASES = new_inductive_definition
  `(!x y. SLC_BETA x y ==> LCR x y) /\
   (!x y. SLC_ETA x y ==> LCR x y) /\
   (!x1 y1 x2 y2. LCR x1 y1 /\ LCR x2 y2
                  ==> LCR (APP x1 x2) (APP y1 y2)) /\
   (!x y. LCR x y ==> LCR (ABS x) (ABS y)) /\
   (!x y. LCR x y ==> LCR y x) /\
   (!x y z. LCR x y /\ LCR y z ==> LCR x z)`;;

let LCR_SYM = prove
 (`!x y. LCR x y ==> LCR y x`,
  REWRITE_TAC[LCR_RULES]);;

let LCR_TRANS = prove
 (`!x y z. LCR x y /\ LCR y z ==> LCR x z`,
  REWRITE_TAC[LCR_RULES]);;

let LCR_BETA = prove
  (`!x y. SLC_BETA x y ==> LCR x y`,
   REWRITE_TAC[LCR_RULES]);;

let LCR_ETA = prove
  (`!x y. SLC_ETA x y ==> LCR x y`,
   REWRITE_TAC[LCR_RULES]);;

let LCR_REFL = prove
  (`!x. LCR x x`,
   MESON_TAC [LCR_TRANS; LCR_SYM; LCR_ETA; SLC_ETA_RULES]);;

let LCR_APP = prove
  (`!x1 y1 x2 y2. LCR x1 y1 /\ LCR x2 y2
                  ==> LCR (APP x1 x2) (APP y1 y2)`,
   REWRITE_TAC[LCR_RULES]);;

let LCR_ABS = prove
  (`!x y. LCR x y ==> LCR (ABS x) (ABS y)`,
   REWRITE_TAC[LCR_RULES]);;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

let SHIFT_AS_SUBST = prove
  (`!x k n. SUBST (SHIFTF k (\i. REF (n + i))) x = SHIFT k n x`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; SHIFTF_SHIFTF; SHIFTF; ADD] THEN
   COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT; REF_INJ; LT] THEN
   ASM_ARITH_TAC);;


(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `!x y i j k.
     SUBST (SHIFTF j (\n. if n = 0 then SHIFT k i y else REF (PRE n)))
      (SHIFT (j + SUC k) i x) =
     SHIFT (j + k) i
      (SUBST (SHIFTF j (\n. if n = 0 then y else REF (PRE n))) x)`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; SHIFTF]);;
e (ASM_CASES_TAC `a < j + SUC k` THEN ASM_REWRITE_TAC []);;
e (ASM_CASES_TAC `a < j` THEN ASM_REWRITE_TAC []);;
e (REWRITE_TAC [SHIFT; REF_INJ]);;
e (ASM_ARITH_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT; REF_INJ]);;
e (MESON_TAC [ADD_SYM; LE_SHIFT_COMM_0]);;
e (ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(i + a < j) /\ ~(a < j) /\
                 ~((i + a) - j = 0) /\ ~(a - j = 0)`
    (fun th -> REWRITE_TAC [th; SHIFT; REF_INJ]));;
e (ASM_ARITH_TAC);;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [ABS_INJ; SHIFTF_SHIFTF; ADD]);;
e (ASM_REWRITE_TAC [ARITH_RULE `SUC (j + SUC k) = SUC j + SUC k`]);;
e (ASM_REWRITE_TAC [ADD]);;
let SHIFT_SUBST_ANCORA = top_thm ();;

let SHIFT_SUBST_ANCORA_0 = prove
  (`!x y i k. SUBST (\n. if n = 0 then SHIFT k i y else REF (PRE n))
               (SHIFT (SUC k) i x) =
              SHIFT k i (SUBST (\n. if n = 0 then y else REF (PRE n)) x)`,
   let th = SPECL [`x:SLC`; `y:SLC`; `i:num`; `0`] SHIFT_SUBST_ANCORA in
   let th = REWRITE_RULE [ADD; SHIFTF_0] th in
   REWRITE_TAC [th]);;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)


g `!x. SUBST (\n. if n = 0 then REF 0 else REF n) x = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SUBST]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `(SHIFTF (SUC 0) (\n. if n = 0 then REF 0 else REF n)) =
                   (\n. if n = 0 then REF 0 else REF n)`
     SUBST1_TAC);;
e (REWRITE_TAC [FUN_EQ_THM; SHIFTF]);;
e (GEN_TAC THEN X_NUM_CASES_TAC `x:num` THEN ASM_REWRITE_TAC [LT]);;
e (REWRITE_TAC [NOT_SUC; SUB_SUC; SUB_0] THEN
   COND_CASES_TAC THEN ASM_REWRITE_TAC [SHIFT; LT; ADD]);;
e (ASM_REWRITE_TAC []);;
let SUBST_REF_0_EXAMPLE = top_thm ();;

(* Non e' piu' vero perche' e' cambiata la definizione di BETA. *)
(*
let SLC_BETA_REF_0_EXAMPLE = prove
  (`!x. SLC_BETA (APP (ABS x) (REF 0)) x`,
   MESON_TAC [SUBST_REF_0_EXAMPLE; SLC_BETA_RULES]);;
*)




(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `!x y k n. SLC_BETA x y ==> SLC_BETA (SHIFT k n x) (SHIFT k n y)`;;
e (SUBGOAL_THEN `!x y . SLC_BETA x y
                        ==> (!k n. SLC_BETA (SHIFT k n x) (SHIFT k n y))`
     (fun th -> MESON_TAC [th]));;
e (MATCH_MP_TAC SLC_BETA_INDUCT);;
e (REPEAT GEN_TAC THEN REWRITE_TAC [SHIFT]);;
e (REWRITE_TAC [SLC_BETA_RW]);;
e (REWRITE_TAC [GSYM SHIFT_SUBST_ANCORA_0]);;
let SHIFT_BETA = top_thm ();;

let LCR_SHIFT = prove
  (`!x y k n. LCR x y ==> LCR (SHIFT k n x) (SHIFT k n y)`,
   SUBGOAL_THEN `!x y. LCR x y ==> !k n. LCR (SHIFT k n x) (SHIFT k n y)`
    (fun th -> MESON_TAC [th]) THEN
   MATCH_MP_TAC LCR_INDUCT THEN REWRITE_TAC [SHIFT] THEN
   MESON_TAC [LCR_RULES; SHIFT_BETA; SHIFT_ETA]);;

let LCR_SHIFTF = prove
  (`!f g k n. (!n. LCR (f n) (g n)) ==> LCR (SHIFTF k f n) (SHIFTF k g n)`,
   REWRITE_TAC [SHIFTF] THEN ASM_MESON_TAC [LCR_SHIFT; LCR_REFL]);;

let LCR_SUBST_FUN = prove
  (`!x f g. (!i. LCR (f i) (g i)) ==> LCR (SUBST f x) (SUBST g x)`,
   MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_SIMP_TAC [SUBST; LCR_APP] THEN
   ASM_MESON_TAC [LCR_ABS; LCR_SHIFTF]);;

g `!f x k. SUBST (SHIFTF k (\n. if n = 0 then f n else REF (PRE n)))
            (SHIFT k (SUC 0) x) = x`;;
e (GEN_TAC THEN MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST]);;
e (REWRITE_TAC [ADD; SHIFTF]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC []);;
e (SUBGOAL_THEN `~(SUC a - k = 0) /\ ~(SUC a < k)`
    (fun th -> REWRITE_TAC [th; SHIFT; REF_INJ]));;
e (ASM_ARITH_TAC);;
e (ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [ABS_INJ; SHIFTF_SHIFTF; ADD]);;
let SUBST_SHIFTF_SHIFT_ENNESIMO = top_thm ();;


let SUBST_SHIFTF_SHIFT_ENNESIMO_0 = prove
  (`!y x. SUBST (\n. if n = 0 then y else REF (PRE n))
           (SHIFT 0 (SUC 0) x) = x`,
   let th = SPECL [`\n:num. y:SLC`; `x:SLC`; `0`]
             SUBST_SHIFTF_SHIFT_ENNESIMO in
   let th = REWRITE_RULE [SHIFTF_0] th in
   REWRITE_TAC [th]);;

g `!x y f. SLC_BETA x y ==> SLC_BETA (SUBST f x) (SUBST f y)`;;
e (SUBGOAL_THEN `!x y. SLC_BETA x y
                       ==> !f. SLC_BETA (SUBST f x) (SUBST f y)`
     (fun th -> MESON_TAC [th]));;
e (MATCH_MP_TAC SLC_BETA_INDUCT);;
e (REPEAT GEN_TAC THEN REWRITE_TAC [SUBST; SLC_BETA_RW; SUBST_SUBST]);;
e (AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_DEF] THEN
   GEN_TAC THEN X_NUM_CASES_TAC `x:num` THEN
   REWRITE_TAC [NOT_SUC; SHIFTF; LT; SUBST]);;
e (REWRITE_TAC [SUB_SUC; SUB; PRE]);;
e (REWRITE_TAC [SUBST_SHIFTF_SHIFT_ENNESIMO_0]);;
let SUBST_BETA_TERM = top_thm ();;

g `!x y f. SLC_ETA x y ==> SLC_ETA (SUBST f x) (SUBST f y)`;;
e (SUBGOAL_THEN
    `!x y. SLC_ETA x y ==> !f. SLC_ETA (SUBST f x) (SUBST f y)`
    (fun th -> MESON_TAC [th]));;
e (MATCH_MP_TAC SLC_ETA_INDUCT THEN REPEAT GEN_TAC);;
e (REWRITE_TAC [SLC_ETA_CASES; SUBST; ABS_INJ; APP_INJ;
                SHIFT_SUBST_LEMMA2; SHIFTF; LT]);;
let SUBST_ETA_TERM = top_thm ();;

let SUBST_LCR_TERM = prove
  (`!x y f. LCR x y ==> LCR (SUBST f x) (SUBST f y)`,
   SUBGOAL_THEN 
    `!x y. LCR x y ==> !f. LCR (SUBST f x) (SUBST f y)`
    (fun th -> MESON_TAC [th]) THEN
   MATCH_MP_TAC LCR_INDUCT THEN REWRITE_TAC [SUBST] THEN
   ASM_MESON_TAC [LCR_RULES; SUBST_BETA_TERM; SUBST_ETA_TERM]);;

let LCR_SUBST = prove
  (`!f g x y. (!n. LCR (f n) (g n)) /\ LCR x y
              ==> LCR (SUBST f x) (SUBST g y)`,
   MESON_TAC [SUBST_LCR_TERM; LCR_SUBST_FUN; LCR_TRANS]);;

let APP1 = new_definition
  `APP1 x = APP (SHIFT 0 (SUC 0) x) (REF 0)`;;

let APP1_LCR = prove
  (`!x y. LCR x y ==> LCR (APP1 x) (APP1 y)`,
   REWRITE_TAC [APP1] THEN MESON_TAC [LCR_RULES; LCR_SHIFT; LCR_REFL]);;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `!x k. SUBST (SHIFTF k (\n. if n = 0 then REF 0 else REF (PRE n)))
          (SHIFT (SUC k) (SUC 0) x) = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   ASM_REWRITE_TAC [SHIFT; SUBST; SHIFTF_SHIFTF; ADD]);;
e (REWRITE_TAC [SHIFTF]);;
e (ASM_CASES_TAC `a < SUC k` THEN ASM_REWRITE_TAC []);;
e (ASM_CASES_TAC `a:num = k` THEN
   ASM_REWRITE_TAC [LT_REFL; SUB_REFL; SHIFT; ADD_0]);;
e (SUBGOAL_THEN `a < k` (fun th -> REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (SUBGOAL_THEN `~(SUC a < k) /\ ~(SUC a - k = 0)`
    (fun th -> REWRITE_TAC [th]));;
e (ASM_ARITH_TAC);;
e (REWRITE_TAC [SHIFT; REF_INJ; LT]);;
e (ASM_ARITH_TAC);;
let SUBST_SHIFT_NON_FINIRANNO_MAI = top_thm ();;

g `!x. SUBST (\n. if n = 0 then REF 0 else REF (PRE n))
          (SHIFT (SUC 0) (SUC 0) x) = x`;;
let th = SPECL [`x:SLC`; `0`] SUBST_SHIFT_NON_FINIRANNO_MAI in
let th = REWRITE_RULE [SHIFTF_0] th in
e (REWRITE_TAC [th]);;
let SUBST_SHIFT_NON_FINIRANNO_MAI_0 = top_thm ();;

(* ------------------------------------------------------------------------- *)
(* ------------------------------------------------------------------------- *)

g `!x. LCR (ABS (APP1 x)) x`;;
e (GEN_TAC THEN REWRITE_TAC [APP1]);;
e (MATCH_MP_TAC LCR_ETA);;
e (REWRITE_TAC [SLC_ETA_RULES]);;
let ABS_APP1_LCR = top_thm ();;

g `!x. LCR (APP1 (ABS x)) x`;;
e (GEN_TAC THEN REWRITE_TAC [APP1; SHIFT]);;
e (MATCH_MP_TAC LCR_BETA);;
e (REWRITE_TAC [SLC_BETA_RW; ARITH_RULE `1 = SUC 0`;
                SUBST_SHIFT_NON_FINIRANNO_MAI_0]);;
let APP1_ABS_LCR = top_thm ();;

