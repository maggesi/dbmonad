(* -*- holl -*- *)

let ASM_ARITH_TAC =
  POP_ASSUM_LIST (MP_TAC o end_itlist CONJ) THEN ARITH_TAC;;

let SUFFICE_TAC thl tm =
  SUBGOAL_THEN tm (fun th -> MESON_TAC (th :: thl));;

let OPTFCT = new_recursive_definition option_RECURSION
  `OPTFCT f NONE = NONE /\
   OPTFCT f (SOME u) = SOME (f u)`;;

let DEFAULT = new_recursive_definition option_RECURSION
  `DEFAULT x f NONE = x /\
   DEFAULT x f (SOME u) = f u`;;

let NUMDEFAULT = new_recursive_definition num_RECURSION
  `NUMDEFAULT x f 0 = x /\
   NUMDEFAULT x f (SUC n) = f n`;;

let SLC_INDUCT, SLC_RECURSION = define_type
  "SLC = REF num
       | VAR A
       | APP SLC SLC
       | ABS SLC";;

let CLOSED_RULES, CLOSED_INDUCT, CLOSED_CASES = new_inductive_definition
  `(!n m. m < n ==> CLOSED n (REF m)) /\
   (!n u. CLOSED n (VAR u)) /\
   (!n x y. CLOSED n x /\ CLOSED n y ==> CLOSED n (APP x y)) /\
   (!n x. CLOSED (SUC n) x ==> CLOSED n (ABS x))`;;

let LE_CLOSED = prove
  (`!(x:A SLC) n m. (n <= m /\ CLOSED n x) ==> CLOSED m x`,
   SUFFICE_TAC []
    `!n (x:A SLC). CLOSED n x ==> (!m. n <= m ==> CLOSED m x)` THEN
   MATCH_MP_TAC CLOSED_INDUCT THEN
   MESON_TAC [CLOSED_RULES; LTE_TRANS; LE_SUC; LT_0]);;

let CLOSED0_CLOSED = prove
  (`!n x. CLOSED 0 x ==> CLOSED n x`,
   MESON_TAC [LE_CLOSED; LE_0]);;

let FCTREF = new_recursive_definition SLC_RECURSION
  `FCTREF f (VAR u) = VAR u /\
   FCTREF f (REF n) = REF (f n) /\
   FCTREF f (APP x y) = APP (FCTREF f x) (FCTREF f y) /\
   FCTREF f (ABS z) = ABS (FCTREF (NUMDEFAULT 0 (\n. SUC (f n))) z)`;;

let SHIFT = new_definition
  `SHIFT = FCTREF SUC`;;

g `SHIFT (REF n) = REF (SUC n) /\
   SHIFT (VAR u) = VAR u /\
   SHIFT (APP x y) = APP (SHIFT x) (SHIFT y)`;;
e (REWRITE_TAC [SHIFT; FCTREF]);;

let FCT = new_recursive_definition SLC_RECURSION
  `FCT f (VAR u) = VAR (f u) /\
   FCT f (REF n) = REF n /\
   FCT f (APP x y) = APP (FCT f x) (FCT f y) /\
   FCT f (ABS z) = ABS (FCT f z)`;;

let SUBST = new_recursive_definition SLC_RECURSION
  `SUBST f (VAR u) = VAR u /\
   SUBST f (REF n) = f n /\
   SUBST f (APP x y) = APP (SUBST f x) (SUBST f y) /\
   SUBST f (ABS z) =
     ABS (SUBST (NUMDEFAULT (REF 0) (\n. SHIFT (f n))) z)`;;

let DEOPT = new_definition
  `DEOPT x = FCT (DEFAULT (REF 0) (\x. x)) (SHIFT x)`;;

let REOPT = new_definition
  `REOPT x = SUBST (NUMDEFAULT (VAR NONE) REF) (FCT SOME x)`;;

g `!x. REOPT (DEOPT x) = x`;;
e (MATCH_MP_TAC SLC_INDUCT THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [DEOPT; REOPT; SHIFT; FCTREF; FCT; SUBST; NUMDEFAULT]);;
r 1;;




let SHIFT = new_recursive_definition SLC_RECURSION
  `SHIFT (REF n) = REF (SUC n) /\
   SHIFT (VAR u) = VAR u /\
   SHIFT (APP x y) = APP (SHIFT x) (SHIFT y) /\
   SHIFT (ABS z) = ABS (SHIFT

let SHIFT = new_recursive_definition SLC_RECURSION
  `SHIFT (VAR NONE) = REF 0 /\
   SHIFT (VAR (SOME u)) = VAR u /\
   SHIFT (REF n) = REF (SUC n) /\
   SHIFT (APP x y) = APP (SHIFT x) (SHIFT y) /\
   SHIFT (ABS z) = ABS (OPTFCT SHIFT)

let SLC_EXISTS_THM = prove
  (`?x:'a SLC. CLOSED 0 x`,
   EXISTS_TAC `ABS (REF 0) : 'a SLC` THEN
   SIMP_TAC [CLOSED_RULES; LT_0]);;

let slc_tybij = new_type_definition
  "slc" ("ABS_slc","REP_slc") SLC_EXISTS_THM;;

(*
let CLOSED_REF = prove
  (`!n m. m < n ==> CLOSED n (REF m)`,
   SIMP_TAC [CLOSED_RULES]);;

let CLOSED_VAR = prove
  (`!n x. CLOSED n (VAR x)`,
   SIMP_TAC [CLOSED_RULES]);;

let CLOSED_APP = prove
  (`!n x y. CLOSED n x /\ CLOSED n y ==> CLOSED n (APP x y)`,
   SIMP_TAC [CLOSED_RULES]);;

let CLOSED_ABS = prove
  (`!n x. CLOSED (SUC n) x ==> CLOSED n (ABS x)`,
   SIMP_TAC [CLOSED_RULES]);;

let SUFFICE_TAC thl th =
  SUBGOAL_THEN th (fun th -> MESON_TAC (th :: thl));;


let LE_CLOSED = time prove
  (`!(x:'a SLC) n m. (n <= m /\ CLOSED n x) ==> CLOSED m x`,
   SUFFICE_TAC []
    `!n (x:'a SLC). CLOSED n x ==> (!m. n <= m ==> CLOSED m x)` THEN
   MATCH_MP_TAC CLOSED_INDUCT THEN REPEAT STRIP_TAC THENL
   [MATCH_MP_TAC CLOSED_REF THEN ASM_ARITH_TAC;
    REWRITE_TAC [CLOSED_VAR];
    ASM_MESON_TAC [CLOSED_APP];
    MATCH_MP_TAC CLOSED_ABS THEN FIRST_X_ASSUM MATCH_MP_TAC THEN
    ASM_ARITH_TAC]);;
*)

