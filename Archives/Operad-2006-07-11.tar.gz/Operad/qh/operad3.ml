needs "/home/maggesi/Trees/HOL/hol_light/Permutation/nummax.ml";;

let CLOSED_DEF = new_definition
  `CLOSED k l <=> ALL (\n. n < k) l`;;

let CLOSED = prove
  (`(!k. CLOSED k []) /\
    (!k h t. CLOSED k (CONS h t) <=> h < k /\ CLOSED k t)`,
   REWRITE_TAC [CLOSED_DEF; ALL]);;

let OPL_DEF = new_definition
  `opl n l1 l2 = ITLIST (\h a. if h < n then CONS h a else
                               if h = n then APPEND l2 a else
                               CONS (PRE (h + GENUSL l2)) a)
                        l1 []`;;

let OPL = prove
  (`(!n l2. opl n [] l2 = []) /\
    (!n h t l2. h < n ==> opl n (CONS h t) l2 = CONS h (opl n t l2)) /\
    (!n t l2. opl n (CONS n t) l2 = APPEND l2 (opl n t l2)) /\
    (!n h t l2. n < h ==> opl n (CONS h t) l2 =
                          CONS (PRE (h + GENUSL l2)) (opl n t l2))`,
   REWRITE_TAC [OPL_DEF] THEN REPEAT CONJ_TAC THEN
   REPEAT STRIP_TAC THEN ASM_REWRITE_TAC [ITLIST; LT_REFL] THEN
   SUBGOAL_THEN `~(h < n) /\ ~(h = n:num)`
     (fun th -> REWRITE_TAC [th]) THEN
   ASM_MESON_TAC [LT_REFL; LT_ANTISYM]);;

let OPL2 = prove
  (`(!n. opl n [] l2 = []) /\
    (!n h t l2. opl n (CONS h t) l2 =
                  if h < n then CONS h (opl n t l2) else
                  if h = n then APPEND l2 (opl n t l2) else
                  CONS (PRE (h + GENUSL l2)) (opl n t l2))`,
   CONJ_TAC THEN REPEAT GEN_TAC THENL
   [REWRITE_TAC [OPL]; 
    COND_CASES_TAC THENL
    [ASM_SIMP_TAC [OPL];
     COND_CASES_TAC THENL
     [ASM_REWRITE_TAC [OPL];
      SUBGOAL_THEN `n < h` (fun th -> ASM_SIMP_TAC [OPL; th]) THEN
      ASM_MESON_TAC [LT_CASES]]]]);;

let PRE_MAX = prove
  (`!n m. PRE (MAX n m) = MAX (PRE n) (PRE m)`,
   REWRITE_TAC [MAX] THEN INDUCT_TAC THEN INDUCT_TAC THEN
   REWRITE_TAC [PRE; LE_0; LE_SUC; LE; NOT_SUC] THEN
   COND_CASES_TAC THEN ASM_REWRITE_TAC [PRE]);;

let MAX_ADD = prove
  (`!n m p. MAX n m + p = MAX (n + p) (m + p)`,
   GEN_TAC THEN GEN_TAC THEN INDUCT_TAC THEN
   ASM_REWRITE_TAC [ADD_SUC; GSYM SUC_MAX; ADD_0]);;

g `(!g op i. OPERAD (g, op, i) <=>
   CLOSED (SUC 0) i /\
   (CLOSED k x /\ CLOSED 

   (!n x y. g (op n x y) = if n < g x then PRE (g x + g y) else g x) /\
   (!n x y. g x < n ==> op n x y = x) /\
   (!n i x. op n i x = if n = 0 then x else i) /\
   (!n i x. op n x i = x) /\
   (!n m x y z. n <= m /\ m < n + g z
                ==> op m (op n x y) z = op n x (op (m - n) y z)))
  ==> OPERAD (GENUSL, opl, [0])`;;
e (DISCH_THEN (fun th -> REWRITE_TAC [th]));;
e (SUBGOAL_THEN
     `!n x y. n < GENUSL x ==> GENUSL (opl n x y) = PRE (GENUSL x + GENUSL y)`
     ASSUME_TAC);;
e (GEN_TAC THEN LIST_INDUCT_TAC THEN GEN_TAC);;
e (REWRITE_TAC [GENUSL; LT]);;
e (REWRITE_TAC [GENUSL; LT_MAX; MAX_ADD; PRE_MAX; PRE; ADD]);;
e (SUBST1_TAC (REWRITE_CONV [LT] `n < SUC h`));;
e (STRIP_TAC THEN ASM_SIMP_TAC [OPL]);;



e (REPEAT CONJ_TAC);;
e (REWRITE_TAC [GENUSL; MAX_0]);;
e (GEN_TAC THEN LIST_INDUCT_TAC THEN GEN_TAC);;
e (REWRITE_TAC [OPL; GENUSL; LT]);;
e (REWRITE_TAC [GENUSL; MAX_ADD; PRE_MAX; ADD; PRE]);;

e (MP_TAC (SPECL [`n:num`; `h:num`] LT_CASES) THEN
   STRIP_TAC THEN ASM_SIMP_TAC [OPL; GENUSL]);;
e (SUBGOAL_THEN `n < MAX (SUC h) (GENUSL t)`
    (fun th -> REWRITE_TAC[th]));;
e (ASM_SIMP_TAC [LT_MAX; ARITH_RULE `n < h ==> n < SUC h`]);;
e (DISJ_CASES_THEN2 SUBST_ALL_TAC (CHOOSE_THEN SUBST_ALL_TAC)
    (SPEC `h:num` num_CASES));;
e (POP_ASSUM MP_TAC THEN REWRITE_TAC [LT]);;
e (REWRITE_TAC [ADD; PRE]);;
e (COND_CASES_TAC);;
e (REWRITE_TAC []);;
e (POP_ASSUM MP_TAC THEN POP_ASSUM MP_TAC THEN
   REWRITE_TAC [MAX] THEN ARITH_TAC);;
