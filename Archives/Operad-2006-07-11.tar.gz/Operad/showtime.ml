(* -*- holl -*- *)

let prove_old = prove and e_old = e;;
let prove = time prove and e = time e;;
