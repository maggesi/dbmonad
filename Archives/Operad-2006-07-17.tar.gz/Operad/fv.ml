(* -*- holl -*- *)

(* ------------------------------------------------------------------------- *)
(*  FV, FV'                                                                  *)
(* ------------------------------------------------------------------------- *)

let FV = new_recursive_definition dbterm_RECURSION
  `(!i. FV (REF i) = {i}) /\
   (!x y. FV (APP x y) = FV x UNION FV y) /\
   (!x. FV (ABS x) = PREIMAGE SUC (FV x))`;;

let FV' = new_recursive_definition dbterm_RECURSION
  `(!k i. FV' k (REF i) = (if i < k then {} else {i - k})) /\
   (!k x y. FV' k (APP x y) = FV' k x UNION FV' k y) /\
   (!k x. FV' k (ABS x) = FV' (SUC k) x)`;;

g `!x k. FV' k x = PREIMAGE ((+) k) (FV x)`;;
e (DBTERM_INDUCT_TAC THEN
   ASM_REWRITE_TAC [FV; FV'; PREIMAGE_UNION; PREIMAGE_SING]);;
e (GEN_TAC THEN COND_CASES_TAC THEN
   REWRITE_TAC [IN_SING; EXTENSION; NOT_IN_EMPTY; IN_ELIM_THM] THEN
   POP_ASSUM MP_TAC THEN ARITH_TAC);;
e (GEN_TAC THEN FIRST_X_ASSUM (fun th -> REWRITE_TAC [GSYM PREIMAGE_o; th]) THEN
   AP_THM_TAC THEN AP_TERM_TAC THEN REWRITE_TAC [FUN_EQ_THM; o_DEF; ADD]);;
let FV'_FV = top_thm ();;

let FV_FV' = prove
  (`!x. FV x = FV' 0 x`,
   GEN_TAC THEN REWRITE_TAC [FV'_FV; PREIMAGE; ADD] THEN SET_TAC []);;

let FV'_SHIFT = prove
  (`!n x k. FV' (n + k) (SHIFT k n x) = FV' k x`,
   GEN_TAC THEN DBTERM_INDUCT_TAC THEN REPEAT GEN_TAC THEN
   ASM_SIMP_TAC [FV'; SHIFT; GSYM ADD_SUC] THEN
   ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [] THEN
   COND_CASES_TAC THEN REWRITE_TAC [SING_INJ] THEN ASM_ARITH_TAC);;

let FV'_SHIFT_0 = MESON [ADD_0; FV'_SHIFT]
  `!n x k. FV' n (SHIFT 0 n x) = FV' 0 x`;;

g `!n x k. FV' k (SHIFT k n x) = IMAGE (\i. n + i) (FV' k x)`;;
e (GEN_TAC THEN DBTERM_INDUCT_TAC THEN GEN_TAC THEN
   ASM_REWRITE_TAC [FV'; SHIFT; IMAGE_UNION]);;
e (ASM_CASES_TAC `a < k` THEN ASM_REWRITE_TAC [IMAGE_EMPTY]);;
e (COND_CASES_TAC THEN REWRITE_TAC [IMAGE_SING; SING_INJ] THEN
   ASM_ARITH_TAC);;
let FV'_SHIFT_IMAGE = top_thm ();;

let FV_SHIFT_0 = prove
  (`!n x. FV (SHIFT 0 n x) = IMAGE (\i. n + i) (FV x)`,
   REWRITE_TAC [FV_FV'; FV'_SHIFT_IMAGE]);;

let FV_SHIFTF = prove
  (`!f k i. FV (SHIFTF k f i) =
           if i < k then {i} else IMAGE (\i. k + i) (FV (f (i - k)))`,
   REPEAT GEN_TAC THEN REWRITE_TAC [SHIFTF] THEN COND_CASES_TAC THEN
   REWRITE_TAC [FV; FV_SHIFT_0]);;

g `!x f. FV (SUBST f x) = {n | ?m. m IN FV x /\ n IN FV (f m)}`;;
e (DBTERM_INDUCT_TAC THEN GEN_TAC THEN ASM_REWRITE_TAC [SUBST; FV]);;
e (SET_TAC []);;
e (SET_TAC []);;
e (REWRITE_TAC [FV_SHIFTF; ADD; ETA_AX; IN_PREIMAGE; SUB]);;
e (REWRITE_TAC [ARITH_RULE `m < SUC 0 <=> m = 0`]);;
e (REWRITE_TAC [EXTENSION; IN_PREIMAGE; IN_ELIM_THM]);;
e (GEN_TAC THEN EQ_TAC THEN STRIP_TAC);;
e (EXISTS_TAC `PRE m`);;
e (X_NUM_CASES_TAC `m:num` THEN
   RULE_ASSUM_TAC (REWRITE_RULE [IN_SING; NOT_SUC; IN_IMAGE;
                                 PRE; ADD; SUC_INJ]));;
e (ASM_MESON_TAC []);;
e (ASM_REWRITE_TAC [PRE]);;
e (SET_TAC []);;
e (EXISTS_TAC `SUC m` THEN ASM_REWRITE_TAC [NOT_SUC]);;
e (REWRITE_TAC [IN_IMAGE; ADD; SUC_INJ; PRE]);;
e (SET_TAC []);;
let FV_SUBST = top_thm ();;

g `!x f g k. (!n. (k + n) IN FV x ==> f n = g n)
             ==> SUBST (SHIFTF k f) x = SUBST (SHIFTF k g) x`;;
e (DBTERM_INDUCT_TAC THEN
   REWRITE_TAC [FV; SUBST; ADD; IN_SING; IN_UNION; IN_PREIMAGE; SHIFTF] THEN
   REPEAT STRIP_TAC);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC [] THEN AP_TERM_TAC THEN
   FIRST_X_ASSUM MATCH_MP_TAC THEN ASM_ARITH_TAC);;
e (ASM_MESON_TAC []);;
e (REWRITE_TAC [SHIFTF_SHIFTF; ADD] THEN ASM_MESON_TAC [ADD]);;
let SUBST_SHIFTF = top_thm ();;

g `!x f g. (!n. n IN FV x ==> f n = g n) ==> SUBST f x = SUBST g x`;;
let th = SPECL [`x:dbterm`; `f:num->dbterm`;  `g:num->dbterm`; `0`] SUBST_SHIFTF in
e (MESON_TAC [REWRITE_RULE [ADD; SHIFTF_0] th]);;
let FV_SUBST_EQ_IMP = top_thm ();;

