(* -*- holl -*- *)

needs "showtime.ml";;
needs "Examples/rstc.ml";;
needs "Operad/lib.ml";;
needs "Operad/dbterm.ml";;
needs "Operad/slc_alt.ml";;
needs "Operad/subst1.ml";;
needs "Operad/fv.ml";;
needs "Operad/lc.ml";;
needs "Operad/operad.ml";;
needs "Operad/lc_operad.ml";;
needs "Operad/lc_exp.ml";;
