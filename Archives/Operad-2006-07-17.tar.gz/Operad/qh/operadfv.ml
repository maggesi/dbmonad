(* -*- holl -*- *)

(* ========================================================================= *)
(*  More definitions and theorems and tactics about lists.                   *)
(*                                                                           *)
(*  Author: Marco Maggesi                                                    *)
(*          University of Florence, Italy                                    *)
(*          http://www.math.unifi.it/~maggesi/                               *)
(*                                                                           *)
(*          (c) Copyright, Marco Maggesi                                     *)
(* ========================================================================= *)

(* needs "/home/maggesi/Trees/HOL/hol_light/Examples/rstc.ml";; *)
needs "/home/maggesi/Trees/HOL/hol_light/Permutation/morelist.ml";;
needs "/home/maggesi/Trees/HOL/hol_light/Operad/lc.ml";;


(* ------------------------------------------------------------------------- *)
(*  Operads.                                                                 *)
(* ------------------------------------------------------------------------- *)

let OPERAD_DEF  = new_definition
  `!(fv:A->num->bool) (op:(num->A)->A->A) (i:num->A).
     OPERAD fv op i <=>
       (!n. fv (i n) = {n}) /\
       (!f g x. (!n. n IN fv x ==> f n = g n) ==> op f x = op g x) /\
       (!f x. fv (op f x) = { n:num | ?m. m IN fv x /\ n IN fv (f m) }) /\
       (!f n. op f (i n) = f n) /\
       (!x. op i x = x) /\
       (!f g x. op g (op f x) = op (\n. op g (f n)) x)`;;

g `OPERAD set_of_list FLATMAP (\n:num. [n])`;;
e (REWRITE_TAC [OPERAD_DEF]);;
e (REPEAT CONJ_TAC);;
e (REWRITE_TAC [set_of_list]);;
e (GEN_TAC THEN GEN_TAC THEN LIST_INDUCT_TAC THEN
   REWRITE_TAC [set_of_list; FLATMAP]);;
e (DISCH_TAC);;
e (SUBGOAL_THEN `FLATMAP f (t:num list) = FLATMAP g t :num list` SUBST1_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (SET_TAC []);;
e (AP_THM_TAC THEN AP_TERM_TAC);;
e (FIRST_X_ASSUM MATCH_MP_TAC);;
e (SET_TAC []);;
e (GEN_TAC THEN LIST_INDUCT_TAC THEN REWRITE_TAC [FLATMAP; set_of_list]);;
e (SET_TAC []);;
e (ASM_REWRITE_TAC [set_of_list_APPEND] THEN SET_TAC []);;
e (REWRITE_TAC [FLATMAP; APPEND_NIL]);;
e (LIST_INDUCT_TAC THEN ASM_REWRITE_TAC [FLATMAP; APPEND]);;
e (GEN_TAC THEN GEN_TAC THEN LIST_INDUCT_TAC THEN
   ASM_REWRITE_TAC [FLATMAP; FLATMAP_APPEND]);;
let LIST_OPERAD = top_thm ();;


g `OPERAD FV SUBST REF`;;
e (REWRITE_TAC [OPERAD_DEF]);;
e (REPEAT CONJ_TAC);;
e (REWRITE_TAC [FV]);;
e (MESON_TAC [FV_SUBST_EQ_IMP]);;
e (REWRITE_TAC [FV_SUBST]);;
e (REWRITE_TAC [SUBST]);;
e (REWRITE_TAC [SUBST_REF_UNIT_L]);;
e (REWRITE_TAC [SUBST_SUBST; o_DEF]);;
let SLC_OPERAD = top_thm ();;


