(* -*- holl -*- *)

let DBTERM_ETA_INDUCT_ALT = prove
  (`!DBTERM_ETA'. (!x. DBTERM_ETA' (ABS (APP0 x)) x)
              ==> (!a0 a1. DBTERM_ETA a0 a1 ==> DBTERM_ETA' a0 a1)`,
    SIMP_TAC [DBTERM_ETA_CASES_ALT]);;

let DBTERM_REL0_RULES, DBTERM_REL0_INDUCT, DBTERM_REL0_CASES =
  new_inductive_definition
  `(!x y. R x y ==> DBTERM_REL0 R x y) /\
   (!x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (ABS x) (ABS y)) /\
   (!x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (APP0 x) (APP0 y)) /\
   (!f x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (SUBST f x) (SUBST f y)) /\
   (!f g x. (?n. DBTERM_REL0 R (f n) (g n) /\ (!i. i = n \/  f i = g i))
            ==> DBTERM_REL0 R (SUBST f x) (SUBST g x))`;;

let DBTERM_REL0_SUBST_TERM = MESON [DBTERM_REL0_RULES]
  `!f x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (SUBST f x) (SUBST f y)`;;

let DBTERM_REL0_SUBST_FUN = MESON [DBTERM_REL0_RULES]
   `!f g x. (?n. DBTERM_REL0 R (f n) (g n) /\ (!i. i = n \/  f i = g i))
            ==> DBTERM_REL0 R (SUBST f x) (SUBST g x)`;;

let DBTERM_REL0_SHIFT = prove
  (`!R k n x y. DBTERM_REL0 R x y
                ==> DBTERM_REL0 R (SHIFT k n x) (SHIFT k n y)`,
   SIMP_TAC [SHIFT_EQ_SUBST; DBTERM_REL0_SUBST_TERM]);;

let DBTERM_REL0_APP_L = prove
  (`!R z x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (APP x z) (APP y z)`,
   SIMP_TAC [APP_EQ_APP0; DBTERM_REL0_RULES]);;

let DBTERM_REL0_APP_R = prove
  (`!R z x y. DBTERM_REL0 R x y ==> DBTERM_REL0 R (APP z x) (APP z y)`,
   REPEAT STRIP_TAC THEN REWRITE_TAC [APP_EQ_APP0] THEN 
   MATCH_MP_TAC DBTERM_REL0_SUBST_FUN THEN ASM_MESON_TAC []);;

let DBTERM_EQV0 = new_definition
  `!R. DBTERM_EQV0 R = RSTC (DBTERM_REL0 R)`;;

let DBTERM_EQV0_INDUCT = prove
  (`!E R. (!x y. R x y ==> E x y) /\
          (!x y. E x y ==> E (APP0 x) (APP0 y)) /\
          (!x y. E x y ==> E (ABS x) (ABS y)) /\
  	  (!f x y. E x y ==> E (SUBST f x) (SUBST f y)) /\
   	  (!f g x. (?n. E (f n) (g n) /\ (!i. i = n \/  f i = g i))
                   ==> E (SUBST f x) (SUBST g x)) /\
          (!x. E x x) /\
          (!x y. E x y ==> E y x) /\
          (!x y z. E x y /\ E y z ==> E x z)
          ==> (!a0 a1. DBTERM_EQV0 R a0 a1 ==> E a0 a1)`,
   GEN_TAC THEN GEN_TAC THEN STRIP_TAC THEN
   REWRITE_TAC [DBTERM_EQV0] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   REPEAT CONJ_TAC THEN ASM_SIMP_TAC [] THENL
   [MATCH_MP_TAC DBTERM_REL0_INDUCT THEN ASM_SIMP_TAC [];
    ASM_MESON_TAC []]);;

let DBTERM_EQV0_INC = prove
  (`!R x y. R x y ==> DBTERM_EQV0 R x y`,
   SIMP_TAC [DBTERM_EQV0; RSTC_INC; DBTERM_REL0_RULES]);;

let DBTERM_EQV0_REFL = prove
  (`!R x. DBTERM_EQV0 R x x`,
   REWRITE_TAC [DBTERM_EQV0; RSTC_REFL]);;

let DBTERM_EQV0_REFL_IMP = MESON [DBTERM_EQV0_REFL]
  `!R x y. x = y ==> DBTERM_EQV0 R x y`;;

let DBTERM_EQV0_SYM = prove
  (`!R x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R y x`,
   REWRITE_TAC [DBTERM_EQV0; RSTC_SYM]);;

let DBTERM_EQV0_TRANS = prove
  (`!R x y z. DBTERM_EQV0 R x y /\ DBTERM_EQV0 R y z ==> DBTERM_EQV0 R x z`,
   REWRITE_TAC [DBTERM_EQV0; RSTC_TRANS]);;

let DBTERM_EQV0_ABS = prove
  (`!R x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (ABS x) (ABS y)`,
   GEN_TAC THEN REWRITE_TAC [DBTERM_EQV0] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL0_RULES]);;

let DBTERM_EQV0_APP0 = prove
  (`!R x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (APP0 x) (APP0 y)`,
   GEN_TAC THEN REWRITE_TAC [DBTERM_EQV0] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL0_RULES]);;

let DBTERM_EQV0_SUBST_TERM = prove
  (`!R f x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (SUBST f x) (SUBST f y)`,
   GEN_TAC THEN
   SUBGOAL_THEN `!x y. DBTERM_EQV0 R x y
                       ==> !f. DBTERM_EQV0 R (SUBST f x) (SUBST f y)`
     (fun th -> MESON_TAC [th]) THEN
   REWRITE_TAC [DBTERM_EQV0] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL0_RULES]);;

let DBTERM_EQV0_SHIFT = prove
  (`!R k n x y. DBTERM_EQV0 R x y
                ==> DBTERM_EQV0 R (SHIFT n k x) (SHIFT n k y)`,
   GEN_TAC THEN GEN_TAC THEN GEN_TAC THEN REWRITE_TAC [DBTERM_EQV0] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN MESON_TAC [RSTC_RULES; DBTERM_REL0_SHIFT]);;

let DBTERM_EQV0_APP_L = prove
  (`!R z x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (APP x z) (APP y z)`,
   GEN_TAC THEN GEN_TAC THEN REWRITE_TAC [DBTERM_EQV0] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL0_RULES; DBTERM_REL0_APP_L]);;

let DBTERM_EQV0_APP_R = prove
  (`!R z x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (APP z x) (APP z y)`,
   GEN_TAC THEN GEN_TAC THEN REWRITE_TAC [DBTERM_EQV0] THEN
   MATCH_MP_TAC RSTC_INDUCT THEN
   MESON_TAC [RSTC_RULES; DBTERM_REL0_RULES; DBTERM_REL0_APP_R]);;

let DBTERM_EQV0_APP = prove
  (`!R x1 y1 x2 y2. DBTERM_EQV0 R x1 y1 /\ DBTERM_EQV0 R x2 y2
                    ==> DBTERM_EQV0 R (APP x1 x2) (APP y1 y2)`,
   MESON_TAC [DBTERM_EQV0_APP_L; DBTERM_EQV0_APP_R; DBTERM_EQV0_TRANS]);;

let DBTERM_EQV0_SUBST_FUN = prove
  (`!R x f g. (?n. DBTERM_EQV0 R (f n) (g n) /\ (!i. i = n \/  f i = g i))
             ==> DBTERM_EQV0 R (SUBST f x) (SUBST g x)`,
   GEN_TAC THEN DBTERM_INDUCT_TAC THEN REPEAT STRIP_TAC THEN
   REWRITE_TAC [SUBST] THENL
   [ASM_MESON_TAC [DBTERM_EQV0_REFL];
    MATCH_MP_TAC DBTERM_EQV0_APP THEN ASM_MESON_TAC [];
    MATCH_MP_TAC DBTERM_EQV0_ABS THEN FIRST_X_ASSUM MATCH_MP_TAC THEN
    EXISTS_TAC `SUC n` THEN CONJ_TAC THENL
    [ASM_SIMP_TAC [SHIFTF; DBTERM_EQV0_SHIFT; TRIVIAL_ARITH];
     NUM_CASES_TAC THEN REWRITE_TAC [SHIFTF; TRIVIAL_ARITH; SHIFT_INJ] THEN
     ASM_MESON_TAC[]]]);;

let DBTERM_EQV0_RULES = MESON [DBTERM_EQV0_INC; DBTERM_EQV0_APP0;
                               DBTERM_EQV0_ABS; DBTERM_EQV0_SUBST_TERM;
 			       DBTERM_EQV0_SUBST_FUN; DBTERM_EQV0_REFL;
 			       DBTERM_EQV0_SYM; DBTERM_EQV0_TRANS]
  `!R. (!x y. R x y ==> DBTERM_EQV0 R x y) /\
       (!x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (ABS x) (ABS y)) /\
       (!x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (APP0 x) (APP0 y)) /\
       (!f x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R (SUBST f x) (SUBST f y)) /\
       (!f g x. (?n. DBTERM_EQV0 R (f n) (g n) /\ (!i. i = n \/  f i = g i))
                ==> DBTERM_EQV0 R (SUBST f x) (SUBST g x)) /\
       (!x. DBTERM_EQV0 R x x) /\
       (!x y. DBTERM_EQV0 R x y ==> DBTERM_EQV0 R y x) /\
       (!x y z. DBTERM_EQV0 R x y /\ DBTERM_EQV0 R y z
                ==> DBTERM_EQV0 R x z)`;;

let DBTERM_EQV0_CASES = prove
  (`!a0 a1.
       DBTERM_EQV0 R a0 a1 <=>
       R a0 a1 \/
       (?x y. a0 = APP0 x /\ a1 = APP0 y /\ DBTERM_EQV0 R x y) \/
       (?x y. a0 = ABS x /\ a1 = ABS y /\ DBTERM_EQV0 R x y) \/
       (?f x y. a0 = SUBST f x /\ a1 = SUBST f y /\ DBTERM_EQV0 R x y) \/
       (?f g x n. a0 = SUBST f x /\ a1 = SUBST g x /\
                  DBTERM_EQV0 R (f n) (g n) /\
		  (!i. n = i \/ f i = g i)) \/
       DBTERM_EQV0 R a1 a0 \/
       (?y. DBTERM_EQV0 R a0 y /\ DBTERM_EQV0 R y a1)`,
   REPEAT GEN_TAC THEN EQ_TAC THENL
   [REWRITE_TAC [DBTERM_EQV0] THEN MESON_TAC [RSTC_CASES; RSTC_RULES];
    MESON_TAC [DBTERM_EQV0_RULES]]);;

let BETA_IMP_APP0_ABS_REL = prove
  (`!x y. DBTERM_BETA x y ==> DBTERM_EQV0 APP0_ABS_REL x y`,
   MATCH_MP_TAC DBTERM_BETA_INDUCT THEN
   SIMP_TAC [APP_EQ_APP0; DBTERM_EQV0_SUBST_TERM; DBTERM_EQV0_INC;
             APP0_ABS_REL_CASES]);;

let ETA_IMP_ABS_APP0_REL = prove
  (`!x y. DBTERM_ETA x y ==> DBTERM_EQV0 ABS_APP0_REL x y`,
   MATCH_MP_TAC DBTERM_ETA_INDUCT_ALT THEN
   SIMP_TAC [DBTERM_EQV0_INC; ABS_APP0_REL_CASES]);;

g `!x y. x === y
         ==> DBTERM_EQV0 (\x y. APP0_ABS_REL x y \/ ABS_APP0_REL x y) x y`;;
e (MATCH_MP_TAC LC_REL_INDUCT THEN REPEAT CONJ_TAC THEN
   SIMP_TAC [DBTERM_EQV0_APP; DBTERM_EQV0_ABS; DBTERM_EQV0_SYM]);;
e (MATCH_MP_TAC DBTERM_BETA_INDUCT THEN
   SIMP_TAC [APP_EQ_APP0; DBTERM_EQV0_SUBST_TERM; DBTERM_EQV0_INC;
             APP0_ABS_REL_CASES]);;
e (MATCH_MP_TAC DBTERM_ETA_INDUCT_ALT THEN
   SIMP_TAC [DBTERM_EQV0_INC; ABS_APP0_REL_CASES]);;
e (MESON_TAC [DBTERM_EQV0_TRANS]);;
let LC_REL_IMP_APP0_ABS_OR_ABS_APP0 = top_thm ();;

let APP0_ABS_IMP_LC_REL = prove
  (`!x y. APP0_ABS_REL x y ==> x === y`,
   MATCH_MP_TAC APP0_ABS_REL_INDUCT THEN REWRITE_TAC [LC_REL_APP0_ABS]);;

let ABS_APP0_IMP_LC_REL = prove
  (`!x y. ABS_APP0_REL x y ==> x === y`,
   MATCH_MP_TAC ABS_APP0_REL_INDUCT THEN REWRITE_TAC [LC_REL_ABS_APP0]);;

g `!x y. DBTERM_EQV0 (\x y. APP0_ABS_REL x y \/ ABS_APP0_REL x y) x y
         ==> x === y`;;
e (REWRITE_TAC [DBTERM_EQV0] THEN MATCH_MP_TAC RSTC_INDUCT THEN
   SIMP_TAC [LC_REL_REFL; LC_REL_SYM] THEN CONJ_TAC);;
e (MATCH_MP_TAC DBTERM_REL0_INDUCT);;
e (SIMP_TAC [LC_REL_APP0; LC_REL_ABS; LC_REL_SUBST_TERM]);;
e (CONJ_TAC);;
e (MESON_TAC [APP0_ABS_IMP_LC_REL; ABS_APP0_IMP_LC_REL]);;
e (REPEAT STRIP_TAC);;
e (MATCH_MP_TAC LC_REL_SUBST_FUN THEN ASM_MESON_TAC [LC_REL_REFL]);;
e (MESON_TAC [LC_REL_TRANS]);;
let APP0_ABS_OR_ABS_APP0_IMP_LC_REL = top_thm ();;

let LC_REL_ALT = MESON [APP0_ABS_OR_ABS_APP0_IMP_LC_REL;
                     LC_REL_IMP_APP0_ABS_OR_ABS_APP0]
   `!x y. x === y <=>
          DBTERM_EQV0 (\x y. APP0_ABS_REL x y \/ ABS_APP0_REL x y) x y`;;
