(* -*- holl -*- *)

(* ------------------------------------------------------------------------- *)
(*  SUBST1                                                                   *)
(* ------------------------------------------------------------------------- *)

let SUBST1 = new_recursive_definition dbterm_RECURSION
  `SUBST1 k y (REF i) =
     (if i = k then y else REF (if i < k then i else PRE i)) /\
   SUBST1 k y (APP x1 x2) = APP (SUBST1 k y x1) (SUBST1 k y x2) /\
   SUBST1 k y (ABS x) = ABS (SUBST1 (SUC k) (SHIFT k (SUC 0) y) x)`;;

g `!x y k. SUBST1 k (SHIFT 0 k y) x =
   SUBST (SHIFTF k (\n. if n = 0 then y else REF (PRE n))) x`;;
e (DBTERM_INDUCT_TAC THEN ASM_REWRITE_TAC [SUBST1; SUBST]);;
e (REWRITE_TAC [ISPEC `SHIFT 0 k` (GSYM IF_DISTRIB); SHIFTF; SHIFT; LT]);;
e (GEN_TAC THEN NUM_CASES_TAC THEN REWRITE_TAC [TRIVIAL_ARITH]);;
e (X_NUM_CASES_TAC `a:num` THEN REWRITE_TAC [TRIVIAL_ARITH; SUB_0]);;
e (ASM_CASES_TAC `n < k` THEN ASM_REWRITE_TAC[] THEN
   REPEAT COND_CASES_TAC THEN ASM_REWRITE_TAC [REF_INJ; SUB_REFL] THEN
   ASM_ARITH_TAC);;
e (ASM_REWRITE_TAC [SHIFT_SHIFT_0; ADD; ADD_0; ADD_SUC; SHIFTF_SHIFTF]);;
let SUBST1_SUBST = top_thm ();;

let SUBST1_SUBST_0 = prove
  (`!x y. SUBST1 0 y x = SUBST (\n. if n = 0 then y else REF (PRE n)) x`,
   let th = SPECL [`x:dbterm`; `y:dbterm`; `0`] SUBST1_SUBST in
   let th = REWRITE_RULE [SHIFT_0; SHIFTF_0] th in
   REWRITE_TAC [th]);;


(* Questo enunciato non `e vero, come si vede seguendo la dim *)
(*
g `!x k y. SUBST1 k y x =
           SUBST (\i. if i < k then REF i else
                      if i = k then y else REF (PRE i)) x`;;
e (DBTERM_INDUCT_TAC THEN ASM_REWRITE_TAC [SUBST1; SUBST]);;
e (MESON_TAC [ARITH_RULE `a < k ==> ~(a = k)`]);;
e (REWRITE_TAC [DBTERM_CONSTR_INJ]);;
e (REPEAT GEN_TAC THEN MATCH_MP_TAC SUBST_FUN_EXTENS);;
e (NUM_CASES_TAC THEN REWRITE_TAC [SHIFTF; TRIVIAL_ARITH]);;
e (REWRITE_TAC [ISPEC `SHIFT 0 (SUC 0)` (GSYM IF_DISTRIB);
                SHIFT; TRIVIAL_ARITH]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
*)


(* Questo `e vero, ma la dim non torna piu'
   (o forse non e' mai tornata??  *)
(*
g `!x k y. SUBST1 k y x =
           SUBST (\i. if i < k then REF i else
                      if i = k then SHIFT 0 k y else REF (PRE i)) x`;;
e (DBTERM_INDUCT_TAC THEN ASM_REWRITE_TAC [SUBST1; SUBST]);;
e (NUM_CASES_TAC THEN GEN_TAC THEN X_NUM_CASES_TAC `a:num` THEN
   ASM_REWRITE_TAC [TRIVIAL_ARITH; SHIFT_0]);;
e (ASM_CASES_TAC `n:num = k` THEN ASM_REWRITE_TAC [LT_REFL; IF_REF]);;
r 1;;
e (REWRITE_TAC [DBTERM_CONSTR_INJ]);;
e (REPEAT GEN_TAC THEN MATCH_MP_TAC SUBST_FUN_EXTENS);;
e (REWRITE_TAC [SHIFTF]);;
e (NUM_CASES_TAC THEN REWRITE_TAC [TRIVIAL_ARITH]);;
e (REWRITE_TAC [LE_SHIFT_COMM_0]);;
e (ASM_CASES_TAC `n < k` THEN ASM_REWRITE_TAC []);;
e (REWRITE_TAC [SHIFT; TRIVIAL_ARITH]);;
e (COND_CASES_TAC THEN ASM_REWRITE_TAC []);;
e (REWRITE_TAC [LE_SHIFT_COMM_0; SHIFT_SHIFT_0; TRIVIAL_ARITH]);;
*)

(* Forse questa definizione di SUBST1 e' migliore??? *)
(* (SHIFT 0 invece di SHIFT k)                       *)
(*
let SUBST1 = new_recursive_definition dbterm_RECURSION
  `SUBST1 k y (REF i) =
     (if i = k then y else REF (if i < k then i else PRE i)) /\
   SUBST1 k y (APP x1 x2) = APP (SUBST1 k y x1) (SUBST1 k y x2) /\
   SUBST1 k y (ABS x) = ABS (SUBST1 (SUC k) (SHIFT 0 (SUC 0) y) x)`;;
*)
